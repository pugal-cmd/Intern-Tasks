<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            // Add slug column after 'name', nullable so existing rows aren't broken
            $table->string('slug')->nullable()->unique()->after('name');

            // Add mrp column if it doesn't already exist
            // (your original migration didn't include it, ProductController does)
            if (!Schema::hasColumn('products', 'mrp')) {
                $table->decimal('mrp', 10, 2)->nullable()->after('slug');
            }
        });
    }

    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropColumn('slug');

            if (Schema::hasColumn('products', 'mrp')) {
                $table->dropColumn('mrp');
            }
        });
    }
};
