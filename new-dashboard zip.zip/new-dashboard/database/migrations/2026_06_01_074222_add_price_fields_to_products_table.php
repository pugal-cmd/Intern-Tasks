<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
  
public function up(): void
{
    Schema::table('products', function (Blueprint $table) {

        if (!Schema::hasColumn('products', 'mrp')) {
            $table->decimal('mrp', 10, 2)->nullable();
        }

        // ONLY add price if it doesn't exist
        if (!Schema::hasColumn('products', 'price')) {
            $table->decimal('price', 10, 2)->nullable();
        }
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            //
        });
    }
};
