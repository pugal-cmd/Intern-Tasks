

<?php $__env->startSection('title', 'Banners'); ?>
<?php $__env->startSection('page-title', 'Banners'); ?>
<?php $__env->startSection('page-subtitle', 'Manage banner slider images'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .slider-container {
        position: relative;
        border-radius: var(--radius);
        overflow: hidden;
        background: var(--bg-card);
        border: 1px solid var(--border);
        aspect-ratio: 16/5;
        margin-bottom: 24px;
    }

    .slide {
        position: absolute;
        inset: 0;
        opacity: 0;
        transition: opacity .6s ease;
    }
    .slide.active { opacity: 1; }
    .slide img { width: 100%; height: 100%; object-fit: cover; }

    .slide-overlay {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: flex-end;
        padding: 40px;
        color: #fff;
        background: linear-gradient(to right, rgba(0,0,0,.6), rgba(0,0,0,0));
    }
    .slide-overlay h2 { font-size: 34px; font-weight: 700; margin: 0; }
    .banner-subtitle { margin-top: 10px; font-size: 16px; opacity: .9; }

    .slider-dots {
        position: absolute;
        bottom: 16px;
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        gap: 8px;
    }
    .dot {
        width: 8px; height: 8px;
        border-radius: 50%;
        background: rgba(255,255,255,.4);
        cursor: pointer;
        transition: all 0.3s;
    }
    .dot.active { background: var(--accent); width: 24px; border-radius: 8px; }

    @media (max-width:768px) {
        .slide-overlay { padding: 20px; }
        .slide-overlay h2 { font-size: 22px; }
        .banner-subtitle { font-size: 13px; }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="fade-in">

    <div class="breadcrumb">
        <a href="<?php echo e(route('admin.home')); ?>">Home</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <span class="current">Banners</span>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-rectangle-ad" style="color:var(--accent);margin-right:8px;"></i>
                Banner Slider
            </h2>
            <button class="btn btn-primary" onclick="openModal('bannerModal')">
                <i class="fas fa-plus"></i> Add Banner
            </button>
        </div>

        
        <?php if($banners->count()): ?>
        <div class="slider-container">
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="slide <?php echo e($i == 0 ? 'active' : ''); ?>">
                <img src="<?php echo e(asset('uploads/banners/'.$banner->image)); ?>" alt="<?php echo e($banner->title); ?>">
                <div class="slide-overlay">
                    <div>
                        <h2><?php echo e($banner->title); ?></h2>
                        <?php if(!empty($banner->subtitle)): ?>
                            <p class="banner-subtitle"><?php echo e($banner->subtitle); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="slider-dots" id="sliderDots"></div>
        </div>
        <?php else: ?>
        <div style="text-align:center; padding:40px; color:var(--text-muted); border:2px dashed var(--border); border-radius:var(--radius); margin-bottom:24px;">
            <i class="fas fa-rectangle-ad" style="font-size:48px; margin-bottom:12px; display:block;"></i>
            <p>No banners yet. Add your first banner above.</p>
        </div>
        <?php endif; ?>

        
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Subtitle</th>
                        <th>Added</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($i + 1); ?></td>
                        <td>
                            <img src="<?php echo e(asset('uploads/banners/'.$banner->image)); ?>" class="td-img">
                        </td>
                        <td style="font-weight:500; color:var(--text-primary);"><?php echo e($banner->title); ?></td>
                        <td><?php echo e($banner->subtitle ?: '—'); ?></td>
                        <td><?php echo e($banner->created_at->format('d M Y')); ?></td>
                        <td>
                            <div style="display:flex; gap:6px; justify-content:center;">
                                <button type="button" class="btn btn-success btn-sm"
                                        onclick='openEditBannerModal(
                                            <?php echo e($banner->id); ?>,
                                            <?php echo json_encode($banner->title, 15, 512) ?>,
                                            <?php echo json_encode($banner->subtitle ?? "", 15, 512) ?>,
                                            <?php echo json_encode(asset("uploads/banners/".$banner->image), 15, 512) ?>
                                        )'>
                                    <i class="fas fa-pen"></i>
                                </button>
                                <form id="del-banner-<?php echo e($banner->id); ?>"
                                      action="<?php echo e(route('admin.banners.destroy', $banner->id)); ?>"
                                      method="POST">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="button" class="btn btn-danger btn-sm"
                                            onclick="confirmDelete('del-banner-<?php echo e($banner->id); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" style="text-align:center; padding:40px; color:var(--text-muted);">
                            No banners found.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<!-- ADD MODAL -->
<div class="modal-overlay" id="bannerModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Add Banner</h3>
            <button class="modal-close" onclick="closeModal('bannerModal')"><i class="fas fa-xmark"></i></button>
        </div>
        <form action="<?php echo e(route('admin.banners.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="form-label">Title *</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Subtitle</label>
                <input type="text" name="subtitle" class="form-control">
            </div>
            <div class="form-group">
                <label class="form-label">Banner Image *</label>
                <div class="upload-zone" onclick="document.getElementById('addBannerImg').click()">
                    <i class="fas fa-cloud-arrow-up"></i>
                    <p>Click to upload banner image</p>
                    <p><span>Recommended: 1920×600px</span></p>
                </div>
                <input type="file" id="addBannerImg" name="image" accept="image/*"
                       style="display:none;" required onchange="previewSingle(this, 'addBannerPreview')">
                <img id="addBannerPreview"
                     style="display:none; margin-top:10px; width:100%; border-radius:var(--radius-sm); max-height:140px; object-fit:cover;">
            </div>
            <div style="display:flex; justify-content:flex-end; gap:10px;">
                <button type="button" class="btn" onclick="closeModal('bannerModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- EDIT MODAL -->
<div class="modal-overlay" id="editBannerModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Edit Banner</h3>
            <button class="modal-close" onclick="closeModal('editBannerModal')"><i class="fas fa-xmark"></i></button>
        </div>
        <form id="editBannerForm" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label class="form-label">Title *</label>
                <input type="text" name="title" id="editBannerTitle" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Subtitle</label>
                <input type="text" name="subtitle" id="editBannerSubtitle" class="form-control">
            </div>
            <div class="form-group">
                <label class="form-label">Current Image</label>
                <img id="editBannerCurrentImg"
                     style="width:100%; max-height:130px; object-fit:cover; border-radius:var(--radius-sm); border:1px solid var(--border); margin-bottom:10px;">
                <label class="form-label">Replace Image (optional)</label>
                <div class="upload-zone" onclick="document.getElementById('editBannerImg').click()">
                    <i class="fas fa-cloud-arrow-up"></i>
                    <p>Click to replace banner image</p>
                </div>
                <input type="file" id="editBannerImg" name="image" accept="image/*"
                       style="display:none;" onchange="previewSingle(this, 'editBannerNewPreview')">
                <img id="editBannerNewPreview"
                     style="display:none; margin-top:10px; width:100%; border-radius:var(--radius-sm); max-height:130px; object-fit:cover;">
            </div>
            <div style="display:flex; justify-content:flex-end; gap:10px;">
                <button type="button" class="btn" onclick="closeModal('editBannerModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
/* ─── SLIDER ─── */
let currentSlide = 0;
const slides = document.querySelectorAll('.slide');
const dotsContainer = document.getElementById('sliderDots');

function initSlider() {
    if (!slides.length || !dotsContainer) return;
    slides.forEach((_, i) => {
        const dot = document.createElement('div');
        dot.className = 'dot' + (i === 0 ? ' active' : '');
        dot.onclick = () => goToSlide(i);
        dotsContainer.appendChild(dot);
    });
}

function goToSlide(n) {
    if (!slides.length) return;
    slides[currentSlide].classList.remove('active');
    dotsContainer.children[currentSlide]?.classList.remove('active');
    currentSlide = (n + slides.length) % slides.length;
    slides[currentSlide].classList.add('active');
    dotsContainer.children[currentSlide]?.classList.add('active');
}

if (slides.length) {
    initSlider();
    setInterval(() => goToSlide(currentSlide + 1), 4000);
}

/* ─── MODALS ─── */
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function previewSingle(input, previewId) {
    const prev = document.getElementById(previewId);
    if (input.files && input.files[0]) {
        prev.src = URL.createObjectURL(input.files[0]);
        prev.style.display = 'block';
    }
}

function openEditBannerModal(id, title, subtitle, imageUrl) {
    document.getElementById('editBannerTitle').value    = title || '';
    document.getElementById('editBannerSubtitle').value = subtitle || '';
    document.getElementById('editBannerForm').action    = `/admin/banners/${id}`;

    const currentImg = document.getElementById('editBannerCurrentImg');
    const newPreview = document.getElementById('editBannerNewPreview');
    const fileInput  = document.getElementById('editBannerImg');

    currentImg.src = imageUrl;
    newPreview.style.display = 'none';
    newPreview.src = '';
    fileInput.value = '';

    openModal('editBannerModal');
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\new-dashboard\resources\views/admin/banners/index.blade.php ENDPATH**/ ?>