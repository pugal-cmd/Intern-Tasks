<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('page-title', 'Home'); ?>
<?php $__env->startSection('page-subtitle', 'Dashboard overview'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    /* ── STATS GRID: 2 rows × 3 columns ── */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
        margin-bottom: 32px;
    }

    @media (max-width: 900px) {
        .stats-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 560px) {
        .stats-grid { grid-template-columns: 1fr; }
    }

    /* ── STAT CARD ── */
    .stat-card {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-radius: var(--radius);
        padding: 24px 22px;
        position: relative;
        overflow: hidden;
        transition: transform 0.22s, box-shadow 0.22s;
        text-decoration: none;
        display: block;
        color: inherit;
    }

    a.stat-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 16px 40px rgba(139,92,246,0.18);
        cursor: pointer;
    }

    .stat-card::before {
        content: '';
        position: absolute;
        top: -40px; right: -40px;
        width: 120px; height: 120px;
        border-radius: 50%;
        opacity: 0.10;
    }
    .stat-card:nth-child(1)::before { background: #8b5cf6; }
    .stat-card:nth-child(2)::before { background: #06b6d4; }
    .stat-card:nth-child(3)::before { background: #16a34a; }
    .stat-card:nth-child(4)::before { background: #f59e0b; }
    .stat-card:nth-child(5)::before { background: #a78bfa; }
    .stat-card:nth-child(6)::before { background: #f43f5e; }

    .stat-icon {
        width: 46px; height: 46px;
        border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        font-size: 20px;
        margin-bottom: 18px;
    }

    .stat-value {
        font-family: 'Space Grotesk', sans-serif;
        font-size: 34px;
        font-weight: 700;
        line-height: 1;
        margin-bottom: 6px;
    }

    .stat-label {
        font-size: 13px;
        color: var(--text-muted);
        font-weight: 500;
        margin-bottom: 0;
    }

    .stat-arrow {
        position: absolute;
        right: 20px;
        bottom: 20px;
        width: 30px; height: 30px;
        border-radius: 50%;
        background: var(--accent-soft);
        display: flex; align-items: center; justify-content: center;
        color: var(--accent);
        font-size: 12px;
        opacity: 0;
        transform: translateX(-4px);
        transition: opacity 0.2s, transform 0.2s;
    }
    a.stat-card:hover .stat-arrow {
        opacity: 1;
        transform: translateX(0);
    }

    /* Color variants for icons */
    .icon-purple { background: rgba(139,92,246,0.12); color: #8b5cf6; }
    .icon-cyan   { background: rgba(6,182,212,0.12);  color: #06b6d4; }
    .icon-green  { background: rgba(22,163,74,0.12);  color: #16a34a; }
    .icon-amber  { background: rgba(245,158,11,0.12); color: #f59e0b; }
    .icon-violet { background: rgba(167,139,250,0.12);color: #a78bfa; }
    .icon-rose   { background: rgba(244,63,94,0.12);  color: #f43f5e; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="fade-in">

    <!-- ── 6 STAT CARDS: 2 rows × 3 cols ── -->
    <div class="stats-grid">

        <!-- Categories (clickable) -->
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="stat-card stagger-1">
            <div class="stat-icon icon-purple">
                <i class="fas fa-layer-group"></i>
            </div>
            <div class="stat-value"><?php echo e($categoryCount ?? 0); ?></div>
            <div class="stat-label">Categories</div>
            <div class="stat-arrow"><i class="fas fa-arrow-right"></i></div>
        </a>

        <!-- Subcategories -->
        <a href="<?php echo e(route('admin.subcategories.index')); ?>" class="stat-card stagger-2">
            <div class="stat-icon icon-cyan">
                <i class="fas fa-sitemap"></i>
            </div>
            <div class="stat-value"><?php echo e($subcategoryCount ?? 0); ?></div>
            <div class="stat-label">Subcategories</div>
            <div class="stat-arrow"><i class="fas fa-arrow-right"></i></div>
        </a>

        <!-- Products -->
        <a href="<?php echo e(route('admin.products.index')); ?>" class="stat-card stagger-3">
            <div class="stat-icon icon-green">
                <i class="fas fa-box"></i>
            </div>
            <div class="stat-value"><?php echo e($productCount ?? 0); ?></div>
            <div class="stat-label">Products</div>
            <div class="stat-arrow"><i class="fas fa-arrow-right"></i></div>
        </a>

        <!-- Gallery -->
        <a href="<?php echo e(route('admin.gallery.index')); ?>" class="stat-card stagger-1">
            <div class="stat-icon icon-amber">
                <i class="fas fa-images"></i>
            </div>
            <div class="stat-value"><?php echo e($galleryCount ?? 0); ?></div>
            <div class="stat-label">Gallery</div>
            <div class="stat-arrow"><i class="fas fa-arrow-right"></i></div>
        </a>

        <!-- Blogs -->
        <a href="<?php echo e(route('admin.blogs.index')); ?>" class="stat-card stagger-2">
            <div class="stat-icon icon-violet">
                <i class="fas fa-pen-to-square"></i>
            </div>
            <div class="stat-value"><?php echo e($blogCount ?? 0); ?></div>
            <div class="stat-label">Blogs</div>
            <div class="stat-arrow"><i class="fas fa-arrow-right"></i></div>
        </a>

        <!-- Banners -->
        <a href="<?php echo e(route('admin.banners.index')); ?>" class="stat-card stagger-3">
            <div class="stat-icon icon-rose">
                <i class="fas fa-rectangle-ad"></i>
            </div>
            <div class="stat-value"><?php echo e($bannerCount ?? 0); ?></div>
            <div class="stat-label">Banners</div>
            <div class="stat-arrow"><i class="fas fa-arrow-right"></i></div>
        </a>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\new-dashboard\resources\views/admin/home/index.blade.php ENDPATH**/ ?>