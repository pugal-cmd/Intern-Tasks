<?php $__env->startSection('title', 'Gallery'); ?>
<?php $__env->startSection('page-title', 'Gallery'); ?>
<?php $__env->startSection('page-subtitle', 'Manage your media gallery'); ?>

<?php $__env->startSection('content'); ?>
<div class="fade-in">
    <div class="breadcrumb">
        <a href="<?php echo e(route('admin.home')); ?>">Home</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <span class="current">Gallery</span>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><i class="fas fa-images" style="color:var(--accent);margin-right:8px;"></i>Gallery</h2>
            <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                <div style="position:relative;">
                    <i class="fas fa-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:13px;pointer-events:none;"></i>
                    <input type="text" id="gallery-search" class="form-control" placeholder="Search images..." style="padding-left:36px; width:220px;">
                </div>
                <button class="btn btn-primary" onclick="openModal('galleryModal')">
                    <i class="fas fa-plus"></i> Add Image
                </button>
            </div>
        </div>

        <div class="img-grid" id="gallery-grid">
            <?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="img-card fade-in" data-name="<?php echo e(strtolower($item->name)); ?>">
                <img src="<?php echo e(asset('uploads/gallery/' . $item->image)); ?>" alt="<?php echo e($item->name); ?>" loading="lazy">
                <div class="img-card-body">
                    <div class="img-card-name"><?php echo e($item->name); ?></div>
                    <div style="font-size:11px; color:var(--text-muted); margin-bottom:10px;">
                        <?php echo e($item->created_at->format('d M Y')); ?>

                    </div>
                    <div class="img-card-actions">
                        <button class="btn btn-success btn-sm" onclick="openEditModal(<?php echo e($item->id); ?>, '<?php echo e($item->name); ?>')">
                            <i class="fas fa-pen"></i>
                        </button>
                        <form id="del-gal-<?php echo e($item->id); ?>" action="<?php echo e(route('admin.gallery.destroy', $item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="button" class="btn btn-danger btn-sm"
                                    onclick="deleteGallery('del-gal-<?php echo e($item->id); ?>')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div style="grid-column:1/-1; text-align:center; padding:60px; color:var(--text-muted);">
                <i class="fas fa-images" style="font-size:48px; margin-bottom:16px; display:block;"></i>
                <p>No images in gallery yet.</p>
            </div>
            <?php endif; ?>
        </div>

        <div id="gallery-empty" style="display:none; text-align:center; padding:40px; color:var(--text-muted);">
            <i class="fas fa-search" style="font-size:32px; margin-bottom:12px; display:block;"></i>
            <p>No images match your search.</p>
        </div>

<div class="pagination">

    <?php if($gallery->currentPage() > 1): ?>
        <a href="<?php echo e($gallery->previousPageUrl()); ?>" class="page-btn">
            &lt;
        </a>
    <?php endif; ?>

    <?php for($i = 1; $i <= $gallery->lastPage(); $i++): ?>
        <a href="<?php echo e($gallery->url($i)); ?>"
           class="page-btn <?php echo e($gallery->currentPage() == $i ? 'active' : ''); ?>">
            <?php echo e($i); ?>

        </a>
    <?php endfor; ?>

    <?php if($gallery->hasMorePages()): ?>
        <a href="<?php echo e($gallery->nextPageUrl()); ?>" class="page-btn">
            &gt;
        </a>
    <?php endif; ?>

</div>    </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="galleryModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Add Gallery Image</h3>
            <button class="modal-close" onclick="closeModal('galleryModal')"><i class="fas fa-xmark"></i></button>
        </div>
        <form action="<?php echo e(route('admin.gallery.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="form-label">Image Name <span style="color:var(--danger)">*</span></label>
                <input type="text" name="name" class="form-control" placeholder="Image title" required>
            </div>
            <div class="form-group">
                <label class="form-label">Image <span style="color:var(--danger)">*</span></label>
                <div class="upload-zone" onclick="document.getElementById('galImg').click()">
                    <i class="fas fa-cloud-arrow-up"></i>
                    <p>Upload image</p>
                    <p>Select multiple images at once</p>
                    <p><span>Any format</span> → stored as WebP ≤500KB</p>
                </div>
                <input type="file" id="galImg" name="images[]" accept="image/*" multiple style="display:none;" required onchange="previewMultiple(this)">
                <div id="preview-container" style="display:flex; flex-wrap:wrap; gap:10px; margin-top:10px;"></div>
            </div>
            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button type="button" class="btn" onclick="closeModal('galleryModal')" style="background:var(--bg-main); color:var(--text-secondary);">Cancel</button>
                <button type="submit" class="btn btn-primary">Upload Image</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editGalleryModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Edit Gallery Item</h3>
            <button class="modal-close" onclick="closeModal('editGalleryModal')"><i class="fas fa-xmark"></i></button>
        </div>
        <form id="editGalleryForm" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label class="form-label">Image Name</label>
                <input type="text" id="editGalName" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Replace Image (optional)</label>
                <div class="upload-zone" onclick="document.getElementById('editGalImg').click()">
                    <i class="fas fa-cloud-arrow-up"></i>
                    <p>Replace image</p>
                </div>
                <input type="file" id="editGalImg" name="image" accept="image/*" style="display:none;" onchange="previewSingle(this,'editGalPreview')">
                <img id="editGalPreview" style="display:none; margin-top:10px; width:100%; border-radius:var(--radius-sm); max-height:150px; object-fit:cover;">
            </div>
            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button type="button" class="btn" onclick="closeModal('editGalleryModal')" style="background:var(--bg-main); color:var(--text-secondary);">Cancel</button>
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function previewMultiple(input) {
    const container = document.getElementById('preview-container');
    container.innerHTML = '';
    if (input.files) {
        Array.from(input.files).forEach(file => {
            const img = document.createElement('img');
            img.src = URL.createObjectURL(file);
            img.style.cssText = 'width:120px;height:120px;object-fit:cover;border-radius:8px;border:1px solid #ddd;';
            container.appendChild(img);
        });
    }
}

function previewSingle(input, previewId) {
    const prev = document.getElementById(previewId);
    if (input.files && input.files[0]) {
        prev.src = URL.createObjectURL(input.files[0]);
        prev.style.display = 'block';
    }
}

function openEditModal(id, name) {
    document.getElementById('editGalName').value = name;
    document.getElementById('editGalleryForm').action = `/admin/gallery/${id}`;
    openModal('editGalleryModal');
}

function deleteGallery(formId) {
    Swal.fire({
        title: 'Delete Image?',
        text: "This action cannot be undone!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById(formId).submit();
        }
    });
}

// Auto search for gallery grid
document.getElementById('gallery-search').addEventListener('input', function () {
    const q = this.value.toLowerCase().trim();
    const cards = document.querySelectorAll('#gallery-grid .img-card');
    let visible = 0;
    cards.forEach(card => {
        const name = card.getAttribute('data-name') || '';
        const show = name.includes(q);
        card.style.display = show ? '' : 'none';
        if (show) visible++;
    });
    document.getElementById('gallery-empty').style.display = visible === 0 ? 'block' : 'none';
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\new-dashboard\resources\views/admin/gallery/index.blade.php ENDPATH**/ ?>