<?php if($paginator->hasPages()): ?>
<nav>
    <ul style="display:flex;justify-content:center;gap:8px;list-style:none;padding:0;margin-top:20px;">

        
        <?php if($paginator->onFirstPage()): ?>
            <li>
                <span class="page-btn">&lt;</span>
            </li>
        <?php else: ?>
            <li>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="page-btn">&lt;</a>
            </li>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_string($element)): ?>
                <li><span class="page-btn"><?php echo e($element); ?></span></li>
            <?php endif; ?>

            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <li>
                            <span class="page-btn active"><?php echo e($page); ?></span>
                        </li>
                    <?php else: ?>
                        <li>
                            <a href="<?php echo e($url); ?>" class="page-btn"><?php echo e($page); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <li>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="page-btn">&gt;</a>
            </li>
        <?php else: ?>
            <li>
                <span class="page-btn">&gt;</span>
            </li>
        <?php endif; ?>

    </ul>
</nav>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\new-dashboard\resources\views/vendor/pagination/custom.blade.php ENDPATH**/ ?>