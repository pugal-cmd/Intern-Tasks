<?php $__env->startSection('title', isset($blog) ? 'Edit Blog' : 'Add Blog'); ?>
<?php $__env->startSection('page-title', isset($blog) ? 'Edit Blog Post' : 'Add Blog Post'); ?>
<?php $__env->startSection('page-subtitle', 'Fill in your blog content below'); ?>

<?php $__env->startPush('styles'); ?>
<style>
.upload-zone {
    border: 2px dashed #cbd5e1;
    border-radius: 8px;
    padding: 16px;
    text-align: center;
    cursor: pointer;
    transition: 0.2s ease;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 4px;
}
.upload-zone:hover { border-color: var(--accent); background: var(--accent-soft); }
.upload-zone i { font-size: 20px; color: var(--text-muted); }
.upload-zone p { margin: 0; font-size: 12px; color: var(--text-secondary); }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="fade-in">

    <div class="breadcrumb">
        <a href="<?php echo e(route('admin.home')); ?>">Home</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <a href="<?php echo e(route('admin.blogs.index')); ?>">Blogs</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <span class="current"><?php echo e(isset($blog) ? 'Edit' : 'Add'); ?></span>
    </div>

    <div class="card" style="max-width: 820px;">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-<?php echo e(isset($blog) ? 'pen' : 'plus'); ?>" style="color:var(--accent);margin-right:8px;"></i>
                <?php echo e(isset($blog) ? 'Edit Blog Post' : 'New Blog Post'); ?>

            </h2>
        </div>

        <form action="<?php echo e(isset($blog) ? route('admin.blogs.update', $blog->id) : route('admin.blogs.store')); ?>"
              method="POST" enctype="multipart/form-data">

            <?php echo csrf_field(); ?>
            <?php if(isset($blog)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <!-- TITLE -->
            <div class="form-group">
                <label class="form-label">Title *</label>
                <input type="text" name="title" class="form-control"
                       placeholder="Enter blog title"
                       value="<?php echo e(old('title', $blog->title ?? '')); ?>" required>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">

                <!-- DATE -->
                <div class="form-group">
                    <label class="form-label">Publish Date *</label>
                    <input type="date" name="date" class="form-control"
                           value="<?php echo e(old('date', isset($blog) ? \Carbon\Carbon::parse($blog->date)->format('Y-m-d') : now()->format('Y-m-d'))); ?>"
                           required>
                </div>

                <!-- IMAGE -->
                <div class="form-group">
                    <label class="form-label">Featured Image</label>

                    
                    <?php if(isset($blog) && $blog->image): ?>
                        <div style="margin-bottom:8px;">
                            <img src="<?php echo e(asset('uploads/blogs/' . $blog->image)); ?>"
                                 id="currentBlogImg"
                                 style="width:100%; max-height:120px; object-fit:cover; border-radius:var(--radius-sm); border:1px solid var(--border);">
                            <p style="font-size:11px; color:var(--text-muted); margin-top:4px;">Current image</p>
                        </div>
                    <?php endif; ?>

                    <div class="upload-zone" onclick="document.getElementById('blogImg').click()">
                        <i class="fas fa-cloud-arrow-up"></i>
                        <p><?php echo e(isset($blog) && $blog->image ? 'Click to replace' : 'Click to upload'); ?></p>
                    </div>

                    <input type="file" id="blogImg" name="image" accept="image/*"
                           style="display:none;" onchange="previewBlogImage(this)">

                    <img id="blogImgPreview"
                         style="display:none; margin-top:8px; width:100%; max-height:120px; object-fit:cover; border-radius:var(--radius-sm);">
                </div>
            </div>

            <!-- CONTENT -->
            <div class="form-group">
                <label class="form-label">Content</label>
                <textarea name="description" id="blogDescription" class="form-control summernote"
                          placeholder="Write your blog content here..."><?php echo e(old('description', $blog->description ?? '')); ?></textarea>
            </div>

            <!-- BUTTONS -->
            <div style="display:flex; gap:12px; justify-content:flex-end;">
                <a href="<?php echo e(route('admin.blogs.index')); ?>" class="btn">Cancel</a>
                <button type="submit" class="btn btn-primary">
                    <?php echo e(isset($blog) ? 'Update' : 'Publish'); ?>

                </button>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function () {
    $('#blogDescription').summernote({
        height: 300,
        placeholder: 'Write your blog content here...',
        toolbar: [
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['font', ['strikethrough', 'superscript', 'subscript']],
            ['fontsize', ['fontsize']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['insert', ['link', 'picture']],
            ['view', ['fullscreen', 'codeview']]
        ]
    });
});

function previewBlogImage(input) {
    const prev = document.getElementById('blogImgPreview');
    const currentImg = document.getElementById('currentBlogImg');

    if (input.files && input.files[0]) {
        prev.src = URL.createObjectURL(input.files[0]);
        prev.style.display = 'block';

        if (currentImg) currentImg.style.opacity = '0.4';
    }
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\new-dashboard\resources\views/admin/blogs/create.blade.php ENDPATH**/ ?>