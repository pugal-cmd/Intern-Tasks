<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('page-title', 'Products'); ?>
<?php $__env->startSection('page-subtitle', 'Manage your product catalogue'); ?>

<?php $__env->startSection('content'); ?>
<div class="fade-in">
    <div class="breadcrumb">
        <a href="<?php echo e(route('admin.home')); ?>">Home</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <span class="current">Products</span>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-box" style="color:var(--accent);margin-right:8px;"></i>
                All Products
            </h2>

            <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">

                <!-- SEARCH -->
                <div style="position:relative;">
                    <i class="fas fa-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:13px;"></i>
                    <input type="text" id="prod-search" class="form-control" placeholder="Search products..." style="padding-left:36px; width:200px;">
                </div>

                <!-- CATEGORY -->
                <select id="prod-cat-filter" class="form-control" style="width:160px;">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <!-- SUBCATEGORY (FIXED WITH data-cat) -->
                <select id="prod-sub-filter" class="form-control" style="width:160px;">
                    <option value="">All Subcategories</option>
                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sub->id); ?>" data-cat="<?php echo e($sub->category_id); ?>">
                            <?php echo e($sub->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add Product
                </a>

            </div>
        </div>

        <div class="table-wrap">
            <table id="prod-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Cat ID</th>
                        <th>Subcat ID</th>
                        <th>Category</th>
                        <th>Subcategory</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr data-name="<?php echo e(strtolower($product->name)); ?>"
                        data-category="<?php echo e($product->category_id); ?>"
                        data-subcategory="<?php echo e($product->subcategory_id); ?>">

                        <td><?php echo e($products->firstItem() + $i); ?></td>

                        <td>
                            <?php if($product->image): ?>
                                <img src="<?php echo e(asset('uploads/products/' . $product->image)); ?>" class="td-img">
                            <?php else: ?>
                                <div class="td-img"></div>
                            <?php endif; ?>
                        </td>

                        <td><?php echo e($product->name); ?></td>

                        <td>#<?php echo e($product->category_id); ?></td>
                        <td>#<?php echo e($product->subcategory_id); ?></td>

                        <td><?php echo e($product->category->name ?? '—'); ?></td>
                        <td><?php echo e($product->subcategory->name ?? '—'); ?></td>

                        <td><?php echo e($product->created_at->format('d M Y')); ?></td>
<td>
    <div style="display:flex; justify-content:flex-start; align-items:center; gap:10px;">

        <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>"
           class="btn btn-success btn-sm"
           style="display:flex; align-items:center; justify-content:center;">
            <i class="fas fa-pen"></i>
        </a>

        <form id="del-prod-<?php echo e($product->id); ?>"
              action="<?php echo e(route('admin.products.destroy', $product->id)); ?>"
              method="POST"
              style="margin:0;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <button type="button"
                    class="btn btn-danger btn-sm"
                    style="display:flex; align-items:center; justify-content:center;"
                    onclick="confirmDelete('del-prod-<?php echo e($product->id); ?>')">
                <i class="fas fa-trash"></i>
            </button>
        </form>

    </div>
</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" style="text-align:center; padding:40px;">
                            No products found
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div id="prod-empty" style="display:none; text-align:center; padding:40px;">
            No products match your filters
        </div>

        <div class="pagination"><?php echo e($products->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function filterProducts() {
    const q     = document.getElementById('prod-search').value.toLowerCase().trim();
    const catId = document.getElementById('prod-cat-filter').value;
    const subId = document.getElementById('prod-sub-filter').value;

    const rows = document.querySelectorAll('#prod-table tbody tr[data-name]');
    let visible = 0;

    rows.forEach(row => {
        const name = row.dataset.name;
        const cat  = row.dataset.category;
        const sub  = row.dataset.subcategory;

        const show =
            name.includes(q) &&
            (catId === '' || cat === catId) &&
            (subId === '' || sub === subId);

        row.style.display = show ? '' : 'none';

        if (show) visible++;
    });

    document.getElementById('prod-empty').style.display = visible === 0 ? 'block' : 'none';
}

/* SEARCH */
document.getElementById('prod-search').addEventListener('input', filterProducts);

/* CATEGORY CHANGE */
document.getElementById('prod-cat-filter').addEventListener('change', function () {
    const catId = this.value;
    const subSelect = document.getElementById('prod-sub-filter');

    subSelect.value = "";

    Array.from(subSelect.options).forEach(opt => {
        if (opt.value === "") return;

        const optCat = opt.getAttribute('data-cat');

        opt.style.display =
            (catId === "" || optCat === catId) ? "" : "none";
    });

    filterProducts();
});

/* SUBCATEGORY */
document.getElementById('prod-sub-filter').addEventListener('change', filterProducts);

/* DELETE */
function confirmDelete(formId) {
    Swal.fire({
        title: 'Are you sure?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#6b7280',
        confirmButtonText: 'Yes delete'
    }).then(result => {
        if (result.isConfirmed) {
            document.getElementById(formId).submit();
        }
    });
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\new-dashboard\resources\views/admin/products/index.blade.php ENDPATH**/ ?>