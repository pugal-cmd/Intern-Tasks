<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <style>
        :root {
            --accent: #8b5cf6;
            --accent2: #a78bfa;
            --accent-soft: rgba(139,92,246,0.10);
            --bg-main: #f8f7ff;
            --bg-card: #ffffff;
            --text-primary: #0f172a;
            --text-secondary: #475569;
            --text-muted: #94a3b8;
            --border: rgba(15,23,42,0.08);
            --radius: 16px;
            --radius-sm: 10px;
            --shadow: 0 20px 60px rgba(139,92,246,0.14);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--bg-main);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        /* Background decorations */
        body::before {
            content: '';
            position: fixed;
            top: -180px; right: -180px;
            width: 500px; height: 500px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(139,92,246,0.18) 0%, transparent 70%);
            pointer-events: none;
        }
        body::after {
            content: '';
            position: fixed;
            bottom: -180px; left: -180px;
            width: 500px; height: 500px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(167,139,250,0.14) 0%, transparent 70%);
            pointer-events: none;
        }

        .login-wrap {
            width: 100%;
            max-width: 440px;
            padding: 24px;
            z-index: 1;
        }

        /* Logo / Brand */
        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            justify-content: center;
            margin-bottom: 32px;
            animation: fadeInDown 0.5s ease both;
        }
        .brand-icon {
            width: 44px; height: 44px;
            background: var(--accent);
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px;
            box-shadow: 0 0 24px rgba(139,92,246,0.45);
        }
        .brand-name {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 22px;
            font-weight: 700;
            color: var(--text-primary);
            letter-spacing: -0.3px;
        }

        /* Card */
        .login-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 36px 32px;
            box-shadow: var(--shadow);
            animation: fadeInUp 0.5s ease 0.1s both;
        }

        .login-heading {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 6px;
        }
        .login-sub {
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 28px;
        }

        /* Session status */
        .status-alert {
            background: rgba(74,222,128,0.1);
            border: 1px solid rgba(74,222,128,0.25);
            color: #16a34a;
            border-radius: var(--radius-sm);
            padding: 10px 14px;
            font-size: 13px;
            margin-bottom: 18px;
        }

        /* Form */
        .form-group {
            margin-bottom: 20px;
        }
        .form-label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 7px;
            letter-spacing: 0.3px;
        }
        .input-wrap {
            position: relative;
        }
        .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 14px;
            pointer-events: none;
        }
        .form-control {
            width: 100%;
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: var(--radius-sm);
            padding: 11px 14px 11px 40px;
            color: var(--text-primary);
            font-family: 'DM Sans', sans-serif;
            font-size: 14px;
            transition: all 0.2s ease;
            outline: none;
        }
        .form-control:focus {
            border-color: var(--accent);
            background: #fff;
            box-shadow: 0 0 0 3px rgba(139,92,246,0.15);
        }
        .form-control::placeholder { color: var(--text-muted); }
  
        .auth-links{
    display:flex;
    align-items:center;
    gap:16px;
}

.register-link,
.forgot-link{
    font-size:13px;
    color:var(--accent);
    text-decoration:none;
    font-weight:500;
    transition:opacity .2s;
}

.register-link:hover,
.forgot-link:hover{
    opacity:.75;
}
.register-link{
    background:var(--accent);
    color:#fff;
    padding:6px 12px;
    border-radius:8px;
    text-decoration:none;
    font-size:12px;
    font-weight:600;
    transition:.2s;
}

.register-link:hover{
    background:#7c3aed;
}

        /* Password toggle */
        .eye-toggle {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            font-size: 14px;
            padding: 0;
            transition: color 0.2s;
        }
        .eye-toggle:hover { color: var(--accent); }

        /* Error */
        .field-error {
            font-size: 12px;
            color: #dc2626;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        /* Remember + Forgot */
        .form-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }
        .remember-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: var(--text-secondary);
            cursor: pointer;
            user-select: none;
        }
        .remember-label input[type="checkbox"] {
            width: 15px; height: 15px;
            accent-color: var(--accent);
            cursor: pointer;
        }
        .forgot-link {
            font-size: 13px;
            color: var(--accent);
            text-decoration: none;
            font-weight: 500;
            transition: opacity 0.2s;
        }
        .forgot-link:hover { opacity: 0.75; }

        /* Submit */
        .btn-login {
            width: 100%;
            background: var(--accent);
            color: #fff;
            border: none;
            border-radius: var(--radius-sm);
            padding: 12px;
            font-family: 'DM Sans', sans-serif;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 4px 20px rgba(139,92,246,0.38);
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .btn-login:hover {
            background: #7c3aed;
            transform: translateY(-1px);
            box-shadow: 0 6px 24px rgba(139,92,246,0.48);
        }
        .btn-login:active { transform: translateY(0); }

        @keyframes fadeInDown { from { opacity:0; transform:translateY(-16px); } to { opacity:1; transform:translateY(0); } }
        @keyframes fadeInUp   { from { opacity:0; transform:translateY(16px);  } to { opacity:1; transform:translateY(0); } }
    </style>
</head>
<body>

<div class="login-wrap">

    <!-- Brand -->
    <div class="brand">
        <div class="brand-icon">⚡</div>
        <span class="brand-name">Dashboard</span>
    </div>

    <div class="login-card">
        <h1 class="login-heading">Welcome back</h1>
        <p class="login-sub">Sign in to your admin panel</p>

        <!-- Session Status -->
        <?php if(session('status')): ?>
            <div class="status-alert"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <!-- Email -->
            <div class="form-group">
                <label class="form-label" for="email">Email Address</label>
                <div class="input-wrap">
                    <i class="fas fa-envelope input-icon"></i>
                    <input id="email"
                           type="email"
                           name="email"
                           class="form-control"
                           placeholder="admin@example.com"
                           value="<?php echo e(old('email')); ?>"
                           required autofocus autocomplete="username">
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="field-error"><i class="fas fa-circle-exclamation"></i> <?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Password -->
            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock input-icon"></i>
                    <input id="password"
                           type="password"
                           name="password"
                           class="form-control"
                           placeholder="Enter your password"
                           required autocomplete="current-password">
                    <button type="button" class="eye-toggle" onclick="togglePassword()">
                        <i class="fas fa-eye" id="eyeIcon"></i>
                    </button>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="field-error"><i class="fas fa-circle-exclamation"></i> <?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Remember + Forgot -->
           <div class="form-footer">
    <label class="remember-label">
        <input type="checkbox" name="remember" id="remember_me">
        Remember me
    </label>

    <div class="auth-links">
        <?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>" class="register-link">
                Register
            </a>
        <?php endif; ?>

        <?php if(Route::has('password.request')): ?>
            <a href="<?php echo e(route('password.request')); ?>" class="forgot-link">
                Forgot Password?
            </a>
        <?php endif; ?>
    </div>
</div>

            <!-- Submit -->
            <button type="submit" class="btn-login">
                <i class="fas fa-arrow-right-to-bracket"></i>
                Sign In
            </button>
        </form>
    </div>
</div>

<script>
function togglePassword() {
    const input = document.getElementById('password');
    const icon  = document.getElementById('eyeIcon');
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\new-dashboard\resources\views/auth/login.blade.php ENDPATH**/ ?>