<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use App\Models\Category;
use App\Models\Subcategory;
use App\Models\Product;
use App\Models\Gallery;
use App\Models\Blog;

class HomeController extends Controller
{
    public function index()
    {
        return view('admin.home.index', [
            'categoryCount'    => Category::count(),
            'subcategoryCount' => Subcategory::count(),
            'productCount'     => Product::count(),
            'galleryCount'     => Gallery::count(),
            'blogCount'        => Blog::count(),
            'bannerCount'      => Banner::count(),
        ]);
    }
}
