<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Subcategory;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;

class ProductController extends Controller
{
    public function index()
    {
        $categories    = Category::orderBy('name')->get();
        $subcategories = Subcategory::orderBy('name')->get();

        $products = Product::with(['category', 'subcategory'])
            ->when(request('cat_id'),    fn($q) => $q->where('category_id',    request('cat_id')))
            ->when(request('subcat_id'), fn($q) => $q->where('subcategory_id', request('subcat_id')))
            ->when(request('search'),    fn($q) => $q->where('name', 'like', '%' . request('search') . '%'))
            ->latest()
            ->paginate(12);

        return view('admin.products.index', compact('categories', 'subcategories', 'products'));
    }

    public function create()
    {
        $categories    = Category::orderBy('name')->get();
        $subcategories = Subcategory::orderBy('name')->get();

        return view('admin.products.create', compact('categories', 'subcategories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'category_id'    => 'required|exists:categories,id',
            'subcategory_id' => 'required|exists:subcategories,id',
            'name'           => 'required|string|max:255',
            'mrp'            => 'required|numeric|min:0',
            'price'          => 'required|numeric|min:0|lte:mrp',
            'description'    => 'nullable|string',
            'image'          => 'nullable|image|mimes:jpg,jpeg,png,gif,webp,bmp|max:10240',
            'slug'           => 'nullable|string|max:255',
        ]);

        // Generate slug from name; use provided slug if given
        $slug = $this->generateUniqueSlug(
            $request->filled('slug') ? $request->slug : $request->name
        );

        $filename = null;
        if ($request->hasFile('image')) {
            $filename = $this->convertToWebP($request->file('image'), 'uploads/products');
        }

        Product::create([
            'category_id'    => $request->category_id,
            'subcategory_id' => $request->subcategory_id,
            'name'           => $request->name,
            'slug'           => $slug,
            'mrp'            => $request->mrp,
            'price'          => $request->price,
            'description'    => $request->description,
            'image'          => $filename,
        ]);

        return redirect()->route('admin.products.index')
            ->with('success', 'Product added successfully.');
    }

    public function edit(Product $product)
    {
        $categories    = Category::orderBy('name')->get();
        $subcategories = Subcategory::where('category_id', $product->category_id)
            ->orderBy('name')
            ->get();

        return view('admin.products.create', compact('product', 'categories', 'subcategories'));
    }

    public function update(Request $request, Product $product)
    {
        $request->validate([
            'category_id'    => 'required|exists:categories,id',
            'subcategory_id' => 'required|exists:subcategories,id',
            'name'           => 'required|string|max:255',
            'mrp'            => 'required|numeric|min:0',
            'price'          => 'required|numeric|min:0|lte:mrp',
            'description'    => 'nullable|string',
            'image'          => 'nullable|image|mimes:jpg,jpeg,png,gif,webp,bmp|max:10240',
            'slug'           => 'nullable|string|max:255',
        ]);

        // Regenerate slug only if name changed or slug field was edited
        $newSlugBase = $request->filled('slug') ? $request->slug : $request->name;
        $slug = $this->generateUniqueSlug($newSlugBase, $product->id);

        $data = [
            'category_id'    => $request->category_id,
            'subcategory_id' => $request->subcategory_id,
            'name'           => $request->name,
            'slug'           => $slug,
            'mrp'            => $request->mrp,
            'price'          => $request->price,
            'description'    => $request->description,
        ];

        if ($request->hasFile('image')) {
            $this->deleteOldFile('uploads/products/' . $product->image);
            $data['image'] = $this->convertToWebP($request->file('image'), 'uploads/products');
        }

        $product->update($data);

        return redirect()->route('admin.products.index')
            ->with('success', 'Product updated.');
    }

    public function destroy(Product $product)
    {
        $this->deleteOldFile('uploads/products/' . $product->image);
        $product->delete();

        return redirect()->route('admin.products.index')
            ->with('success', 'Product deleted.');
    }

    public function getSubcategories($category_id)
    {
        $subcategories = Subcategory::where('category_id', $category_id)->get();
        return response()->json($subcategories);
    }

    /* ─── SLUG HELPER ─── */
    protected function generateUniqueSlug(string $value, ?int $ignoreId = null): string
    {
        $base = Str::slug($value);
        $slug = $base;
        $i    = 1;

        while (
            Product::where('slug', $slug)
                ->when($ignoreId, fn($q) => $q->where('id', '!=', $ignoreId))
                ->exists()
        ) {
            $slug = $base . '-' . $i++;
        }

        return $slug;
    }

    /* ─── IMAGE HELPERS ─── */
    protected function convertToWebP($file, string $directory): string
    {
        $filename = uniqid('img_', true) . '.webp';
        $path     = public_path($directory . '/' . $filename);

        if (!file_exists(public_path($directory))) {
            mkdir(public_path($directory), 0777, true);
        }

        $image = Image::make($file)
            ->resize(1200, null, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
            });

        $image->encode('webp', 85)->save($path);

        if (file_exists($path) && filesize($path) > 500 * 1024) {
            $image->encode('webp', 65)->save($path);
        }

        return $filename;
    }

    protected function deleteOldFile(?string $path): void
    {
        if ($path && file_exists(public_path($path))) {
            unlink(public_path($path));
        }
    }
}
