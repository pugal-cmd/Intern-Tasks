<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::latest()->paginate(10);
        return view('admin.categories.index', compact('categories'));
    }

    public function create()
    {
        return view('admin.categories.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'  => 'required|max:255',
            'image' => 'required|image|mimes:jpg,jpeg,png,gif,webp|max:10240'
        ]);

        $filename = null;

        if ($request->hasFile('image')) {
            $filename = $this->uploadImage($request->file('image'));
        }

        Category::create([
            'name'  => $request->name,
            'image' => $filename
        ]);

        return redirect()
            ->route('admin.categories.index')
            ->with('success', 'Category created successfully');
    }

    public function edit(Category $category)
    {
        return view('admin.categories.create', compact('category'));
    }

    public function update(Request $request, Category $category)
    {
        $request->validate([
            'name'  => 'required|max:255',
            'image' => 'required|image|mimes:jpg,jpeg,png,gif,webp|max:10240'
        ]);

        $data = [
            'name' => $request->name
        ];

        if ($request->hasFile('image')) {

            // SAFE DELETE OLD IMAGE
            $this->deleteOldFile($category->image);

            $data['image'] = $this->uploadImage($request->file('image'));
        }

        $category->update($data);

        return redirect()
            ->route('admin.categories.index')
            ->with('success', 'Category updated successfully');
    }

    public function destroy(Category $category)
    {
        // SAFE DELETE (FIXED)
        $this->deleteOldFile($category->image);

        $category->delete();

        return redirect()
            ->route('admin.categories.index')
            ->with('success', 'Category deleted successfully');
    }

    // Upload image as WebP
    protected function uploadImage($file): string
    {
        $filename = uniqid('cat_', true) . '.webp';

        $path = public_path('uploads/categories');

        if (!file_exists($path)) {
            mkdir($path, 0777, true);
        }

        Image::make($file)
            ->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
            })
            ->encode('webp', 80)
            ->save($path . '/' . $filename);

        return $filename;
    }

    // FIXED DELETE FUNCTION (IMPORTANT)
    protected function deleteOldFile($filename): void
    {
        if (empty($filename)) {
            return;
        }

        $fullPath = public_path('uploads/categories/' . $filename);

        if (is_file($fullPath)) {
            unlink($fullPath);
        }
    }
}