<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\Http\Request;

class SubcategoryController extends Controller
{
    public function index()
    {
        $categories = Category::orderBy('name')->get();

        $subcategories = Subcategory::with('category')
            ->when(request('cat_id'), fn($q) => $q->where('category_id', request('cat_id')))
            ->latest()
            ->paginate(16);

        return view('admin.subcategories.index', compact('categories', 'subcategories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'category_id' => 'required|exists:categories,id',
            'name'        => 'required|string|max:255',
        ]);

        Subcategory::create($request->only('category_id', 'name'));

        return redirect()->route('admin.subcategories.index')->with('success', 'Subcategory added.');
    }

    public function update(Request $request, Subcategory $subcategory)
    {
        $request->validate([
            'category_id' => 'required|exists:categories,id',
            'name'        => 'required|string|max:255',
        ]);

        $subcategory->update($request->only('category_id', 'name'));

        return redirect()->route('admin.subcategories.index')->with('success', 'Subcategory updated.');
    }

    public function destroy(Subcategory $subcategory)
    {
        $subcategory->delete();
        return redirect()->route('admin.subcategories.index')->with('success', 'Subcategory deleted.');
    }

    /** AJAX: get subcategories by category */
    public function byCategory(Category $category)
    {
        return response()->json($category->subcategories()->orderBy('name')->get(['id', 'name']));
    }
}
