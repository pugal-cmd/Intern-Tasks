<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Blog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Intervention\Image\Facades\Image;

class BlogController extends Controller
{
    public function index()
    {
        $blogs = Blog::latest()->paginate(12);
        return view('admin.blogs.index', compact('blogs'));
    }

    public function create()
    {
        return view('admin.blogs.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'       => 'required|string|max:500',
            'date'        => 'required|date',
            'description' => 'nullable|string',
            'image'       => 'nullable|image|mimes:jpg,jpeg,png,webp|max:10240',
        ]);

        $filename = null;

        if ($request->hasFile('image')) {
            $filename = $this->convertToWebP($request->file('image'), 'uploads/blogs');
        }

        Blog::create([
            'title'       => $request->title,
            'date'        => $request->date,
            'description' => $request->description,
            'image'       => $filename ?? null
        ]);

        return redirect()->route('admin.blogs.index')
            ->with('success', 'Blog created successfully');
    }

    public function edit($id)
    {
        $blog = Blog::findOrFail($id);
        return view('admin.blogs.create', compact('blog'));
    }

    public function update(Request $request, $id)
    {
        $blog = Blog::findOrFail($id);

        $request->validate([
            'title'       => 'required|string|max:500',
            'date'        => 'required|date',
            'description' => 'nullable|string',
            'image'       => 'nullable|image|mimes:jpg,jpeg,png,webp|max:10240',
        ]);

        $data = [
            'title'       => $request->title,
            'date'        => $request->date,
            'description' => $request->description,
        ];

        if ($request->hasFile('image')) {

            $this->deleteOldFile('uploads/blogs/' . $blog->image);

            $newImage = $this->convertToWebP($request->file('image'), 'uploads/blogs');

            if ($newImage) {
                $data['image'] = $newImage;
            }
        }

        $blog->update($data);

        return redirect()->route('admin.blogs.index')
            ->with('success', 'Blog updated successfully');
    }

    public function destroy($id)
    {
        $blog = Blog::findOrFail($id);

        $this->deleteOldFile('uploads/blogs/' . $blog->image);

        $blog->delete();

        return redirect()->route('admin.blogs.index')
            ->with('success', 'Blog deleted successfully');
    }

    // =========================
    // IMAGE CONVERSION FIXED
    // =========================
    protected function convertToWebP($file, string $directory): ?string
    {
        try {
            $filename = uniqid('img_', true) . '.webp';

            $directoryPath = public_path($directory);

            if (!file_exists($directoryPath)) {
                mkdir($directoryPath, 0777, true);
            }

            $path = $directoryPath . '/' . $filename;

            $image = Image::make($file);

            $image->resize(1200, null, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
            });

            $image->encode('webp', 85)->save($path);

            return $filename;

        } catch (\Exception $e) {

            Log::error('Blog image upload failed: ' . $e->getMessage());

            return null;
        }
    }

    // =========================
    // DELETE FILE SAFELY
    // =========================
    protected function deleteOldFile(?string $relativePath): void
    {
        if ($relativePath) {
            $fullPath = public_path($relativePath);

            if (File::exists($fullPath)) {
                File::delete($fullPath);
            }
        }
    }
}