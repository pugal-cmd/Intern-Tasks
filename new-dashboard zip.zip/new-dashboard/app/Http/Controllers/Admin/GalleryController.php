<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Gallery;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;

class GalleryController extends Controller
{
    public function index()
    {
        $gallery = Gallery::latest()->paginate(16);
        return view('admin.gallery.index', compact('gallery'));
    }

   public function store(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:255',
        'images' => 'required',
        'images.*' => 'image|mimes:jpg,jpeg,png,gif,webp,bmp|max:10240',
    ]);

    $startNumber = Gallery::where('name', 'like', $request->name . '%')->count() + 1;

    foreach ($request->file('images') as $index => $image) {

        $filename = $this->convertToWebP(
            $image,
            'uploads/gallery'
        );

        Gallery::create([
            'name'  => $request->name . ' ' . ($startNumber + $index),
            'image' => $filename,
        ]);
    }

    return redirect()
        ->route('admin.gallery.index')
        ->with('success', 'Images uploaded successfully.');
}
    public function update(Request $request, Gallery $gallery)
    {
        $request->validate([
            'name'  => 'required|string|max:255',
            'image' => 'required|image|mimes:jpg,jpeg,png,gif,webp,bmp|max:10240',
        ]);

        $data = [
            'name' => $request->name
        ];

        if ($request->hasFile('image')) {
            $this->deleteOldFile('uploads/gallery/' . $gallery->image);

            $data['image'] = $this->convertToWebP(
                $request->file('image'),
                'uploads/gallery'
            );
        }

        $gallery->update($data);

        return redirect()
            ->route('admin.gallery.index')
            ->with('success', 'Gallery item updated.');
    }

    public function destroy(Gallery $gallery)
    {
        $this->deleteOldFile('uploads/gallery/' . $gallery->image);
        $gallery->delete();

        return redirect()
            ->route('admin.gallery.index')
            ->with('success', 'Image deleted.');
    }

    // ✅ FIXED IMAGE CONVERSION (NO ERROR)
    protected function convertToWebP($file, string $directory): string
{
    $filename = uniqid('gal_', true) . '.webp';

    $fullDir = public_path($directory);
    $path = $fullDir . '/' . $filename;

    // ✅ ensure directory exists
    if (!file_exists($fullDir)) {
        mkdir($fullDir, 0777, true);
    }

    $image = Image::make($file)
        ->resize(1200, null, function ($constraint) {
            $constraint->aspectRatio();
            $constraint->upsize();
        })
        ->encode('webp', 85);

    // ✅ extra safety check before saving
    if (!is_writable($fullDir)) {
        throw new \Exception("Directory not writable: " . $fullDir);
    }

    $image->save($path);

    return $filename;
}

    protected function deleteOldFile(?string $relativePath): void
    {
        if ($relativePath && file_exists(public_path($relativePath))) {
            unlink(public_path($relativePath));
        }
    }
}