<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Intervention\Image\Facades\Image;

class BannerController extends Controller
{
    public function index()
    {
        $banners = Banner::latest()->get();
        return view('admin.banners.index', compact('banners'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'    => 'required|string|max:255',
            'subtitle' => 'nullable|string|max:255',
            'image'    => 'required|image|mimes:jpg,jpeg,png,gif,webp,bmp|max:10240',
        ]);

        $filename = $this->convertToWebP($request->file('image'), 'uploads/banners');

        Banner::create([
            'title'    => $request->title,
            'subtitle' => $request->subtitle,
            'image'    => $filename,
        ]);

        return redirect()->route('admin.banners.index')
            ->with('success', 'Banner added successfully.');
    }

    public function update(Request $request, Banner $banner)
    {
        $request->validate([
            'title'    => 'required|string|max:255',
            'subtitle' => 'nullable|string|max:255',
            'image'    => 'nullable|image|mimes:jpg,jpeg,png,gif,webp,bmp|max:10240',
        ]);

        $data = [
            'title'    => $request->title,
            'subtitle' => $request->subtitle,
        ];

        if ($request->hasFile('image')) {
            $this->deleteOldFile('uploads/banners/' . $banner->image);
            $data['image'] = $this->convertToWebP($request->file('image'), 'uploads/banners');
        }

        $banner->update($data);

        return redirect()->route('admin.banners.index')
            ->with('success', 'Banner updated successfully.');
    }

    public function destroy(Banner $banner)
    {
        $this->deleteOldFile('uploads/banners/' . $banner->image);
        $banner->delete();

        return redirect()->route('admin.banners.index')
            ->with('success', 'Banner deleted successfully.');
    }

    protected function convertToWebP($file, string $directory): string
    {
        $filename = uniqid('img_', true) . '.webp';
        $path     = public_path($directory . '/' . $filename);

        if (!file_exists(public_path($directory))) {
            mkdir(public_path($directory), 0777, true);
        }

        $image = Image::make($file)
            ->resize(1920, null, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
            })
            ->encode('webp', 85);

        $image->save($path);

        // Re-compress if still too large
        if (file_exists($path) && filesize($path) > 500 * 1024) {
            Image::make($file)
                ->resize(1920, null, function ($c) { $c->aspectRatio(); $c->upsize(); })
                ->encode('webp', 65)
                ->save($path);
        }

        return $filename;
    }

    protected function deleteOldFile(?string $relativePath): void
    {
        if ($relativePath) {
            $fullPath = public_path($relativePath);
            if (File::exists($fullPath)) {
                File::delete($fullPath);
            }
        }
    }
}
