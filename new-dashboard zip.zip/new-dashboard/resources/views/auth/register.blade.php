<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <style>
        :root {
            --accent: #8b5cf6;
            --accent2: #a78bfa;
            --accent-soft: rgba(139,92,246,0.10);
            --bg-main: #f8f7ff;
            --bg-card: #ffffff;
            --text-primary: #0f172a;
            --text-secondary: #475569;
            --text-muted: #94a3b8;
            --border: rgba(15,23,42,0.08);
            --radius: 16px;
            --radius-sm: 10px;
            --shadow: 0 20px 60px rgba(139,92,246,0.14);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--bg-main);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }

        body::before {
            content: '';
            position: fixed;
            top: -180px;
            right: -180px;
            width: 500px;
            height: 500px;
            border-radius: 50%;
            background: radial-gradient(circle,
                    rgba(139,92,246,0.18) 0%,
                    transparent 70%);
        }

        body::after {
            content: '';
            position: fixed;
            bottom: -180px;
            left: -180px;
            width: 500px;
            height: 500px;
            border-radius: 50%;
            background: radial-gradient(circle,
                    rgba(167,139,250,0.14) 0%,
                    transparent 70%);
        }

        .register-wrap {
            width: 100%;
            max-width: 500px;
            padding: 24px;
            z-index: 1;
        }

        .brand {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-bottom: 32px;
            animation: fadeInDown .5s ease both;
        }

        .brand-icon {
            width: 44px;
            height: 44px;
            background: var(--accent);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 24px rgba(139,92,246,.45);
            font-size: 20px;
        }

        .brand-name {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 22px;
            font-weight: 700;
            color: var(--text-primary);
        }

        .register-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 36px 32px;
            box-shadow: var(--shadow);
            animation: fadeInUp .5s ease .1s both;
        }

        .register-heading {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 6px;
        }

        .register-sub {
            color: var(--text-muted);
            font-size: 13px;
            margin-bottom: 28px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            display: block;
            margin-bottom: 7px;
            font-size: 12px;
            font-weight: 600;
            color: var(--text-secondary);
        }

        .input-wrap {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
        }

        .form-control {
            width: 100%;
            padding: 11px 14px 11px 40px;
            border: 1px solid #e5e7eb;
            border-radius: var(--radius-sm);
            background: #f9fafb;
            font-size: 14px;
            outline: none;
            transition: .2s;
        }

        .form-control:focus {
            background: white;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(139,92,246,.15);
        }

        .eye-toggle {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            border: none;
            background: transparent;
            cursor: pointer;
            color: var(--text-muted);
        }

        .field-error {
            color: #dc2626;
            font-size: 12px;
            margin-top: 5px;
        }

        .footer-links {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 24px;
        }

        .login-link {
            color: var(--accent);
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
        }

        .login-link:hover {
            opacity: .8;
        }

        .btn-register {
            background: var(--accent);
            color: white;
            border: none;
            border-radius: var(--radius-sm);
            padding: 12px 18px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 4px 20px rgba(139,92,246,.38);
            transition: .2s;
        }

        .btn-register:hover {
            background: #7c3aed;
            transform: translateY(-1px);
        }

        @keyframes fadeInDown {
            from {
                opacity:0;
                transform:translateY(-16px);
            }
            to {
                opacity:1;
                transform:translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity:0;
                transform:translateY(16px);
            }
            to {
                opacity:1;
                transform:translateY(0);
            }
        }
    </style>
</head>
<body>

<div class="register-wrap">

    <div class="brand">
        <div class="brand-icon">⚡</div>
        <span class="brand-name">Dashboard</span>
    </div>

    <div class="register-card">

        <h1 class="register-heading">Create Account</h1>
        <p class="register-sub">Register a new admin account</p>

        <form method="POST" action="{{ route('register') }}">
            @csrf

            <!-- Name -->
            <div class="form-group">
                <label class="form-label">Full Name</label>
                <div class="input-wrap">
                    <i class="fas fa-user input-icon"></i>
                    <input type="text"
                           name="name"
                           class="form-control"
                           value="{{ old('name') }}"
                           placeholder="Enter your full name"
                           required autofocus>
                </div>

                @error('name')
                    <p class="field-error">{{ $message }}</p>
                @enderror
            </div>

            <!-- Email -->
            <div class="form-group">
                <label class="form-label">Email Address</label>
                <div class="input-wrap">
                    <i class="fas fa-envelope input-icon"></i>
                    <input type="email"
                           name="email"
                           class="form-control"
                           value="{{ old('email') }}"
                           placeholder="admin@example.com"
                           required>
                </div>

                @error('email')
                    <p class="field-error">{{ $message }}</p>
                @enderror
            </div>

            <!-- Password -->
            <div class="form-group">
                <label class="form-label">Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password"
                           name="password"
                           id="password"
                           class="form-control"
                           placeholder="Enter password"
                           required>

                    <button type="button" class="eye-toggle"
                            onclick="togglePassword('password','eye1')">
                        <i id="eye1" class="fas fa-eye"></i>
                    </button>
                </div>

                @error('password')
                    <p class="field-error">{{ $message }}</p>
                @enderror
            </div>

            <!-- Confirm Password -->
            <div class="form-group">
                <label class="form-label">Confirm Password</label>
                <div class="input-wrap">
                    <i class="fas fa-shield-halved input-icon"></i>
                    <input type="password"
                           name="password_confirmation"
                           id="confirmPassword"
                           class="form-control"
                           placeholder="Confirm password"
                           required>

                    <button type="button" class="eye-toggle"
                            onclick="togglePassword('confirmPassword','eye2')">
                        <i id="eye2" class="fas fa-eye"></i>
                    </button>
                </div>

                @error('password_confirmation')
                    <p class="field-error">{{ $message }}</p>
                @enderror
            </div>

            <div class="footer-links">
                <a href="{{ route('login') }}" class="login-link">
                    Already registered?
                </a>

                <button type="submit" class="btn-register">
                    <i class="fas fa-user-plus"></i>
                    Register
                </button>
            </div>

        </form>
    </div>
</div>

<script>
function togglePassword(inputId, iconId) {

    const input = document.getElementById(inputId);
    const icon = document.getElementById(iconId);

    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}
</script>

</body>
</html>