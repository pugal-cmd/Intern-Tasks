@extends('layouts.admin')
@section('title', 'Products')
@section('page-title', 'Products')
@section('page-subtitle', 'Manage your product catalogue')

@section('content')
<div class="fade-in">
    <div class="breadcrumb">
        <a href="{{ route('admin.home') }}">Home</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <span class="current">Products</span>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-box" style="color:var(--accent);margin-right:8px;"></i>
                All Products
            </h2>

            <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">

                <!-- SEARCH -->
                <div style="position:relative;">
                    <i class="fas fa-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:13px;"></i>
                    <input type="text" id="prod-search" class="form-control" placeholder="Search products..." style="padding-left:36px; width:200px;">
                </div>

                <!-- CATEGORY -->
                <select id="prod-cat-filter" class="form-control" style="width:160px;">
                    <option value="">All Categories</option>
                    @foreach($categories as $cat)
                        <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                    @endforeach
                </select>

                <!-- SUBCATEGORY (FIXED WITH data-cat) -->
                <select id="prod-sub-filter" class="form-control" style="width:160px;">
                    <option value="">All Subcategories</option>
                    @foreach($subcategories as $sub)
                        <option value="{{ $sub->id }}" data-cat="{{ $sub->category_id }}">
                            {{ $sub->name }}
                        </option>
                    @endforeach
                </select>

                <a href="{{ route('admin.products.create') }}" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add Product
                </a>

            </div>
        </div>

        <div class="table-wrap">
            <table id="prod-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Cat ID</th>
                        <th>Subcat ID</th>
                        <th>Category</th>
                        <th>Subcategory</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse($products as $i => $product)
                    <tr data-name="{{ strtolower($product->name) }}"
                        data-category="{{ $product->category_id }}"
                        data-subcategory="{{ $product->subcategory_id }}">

                        <td>{{ $products->firstItem() + $i }}</td>

                        <td>
                            @if($product->image)
                                <img src="{{ asset('uploads/products/' . $product->image) }}" class="td-img">
                            @else
                                <div class="td-img"></div>
                            @endif
                        </td>

                        <td>{{ $product->name }}</td>

                        <td>#{{ $product->category_id }}</td>
                        <td>#{{ $product->subcategory_id }}</td>

                        <td>{{ $product->category->name ?? '—' }}</td>
                        <td>{{ $product->subcategory->name ?? '—' }}</td>

                        <td>{{ $product->created_at->format('d M Y') }}</td>
<td>
    <div style="display:flex; justify-content:flex-start; align-items:center; gap:10px;">

        <a href="{{ route('admin.products.edit', $product->id) }}"
           class="btn btn-success btn-sm"
           style="display:flex; align-items:center; justify-content:center;">
            <i class="fas fa-pen"></i>
        </a>

        <form id="del-prod-{{ $product->id }}"
              action="{{ route('admin.products.destroy', $product->id) }}"
              method="POST"
              style="margin:0;">
            @csrf
            @method('DELETE')

            <button type="button"
                    class="btn btn-danger btn-sm"
                    style="display:flex; align-items:center; justify-content:center;"
                    onclick="confirmDelete('del-prod-{{ $product->id }}')">
                <i class="fas fa-trash"></i>
            </button>
        </form>

    </div>
</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="9" style="text-align:center; padding:40px;">
                            No products found
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div id="prod-empty" style="display:none; text-align:center; padding:40px;">
            No products match your filters
        </div>

        <div class="pagination">{{ $products->links() }}</div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function filterProducts() {
    const q     = document.getElementById('prod-search').value.toLowerCase().trim();
    const catId = document.getElementById('prod-cat-filter').value;
    const subId = document.getElementById('prod-sub-filter').value;

    const rows = document.querySelectorAll('#prod-table tbody tr[data-name]');
    let visible = 0;

    rows.forEach(row => {
        const name = row.dataset.name;
        const cat  = row.dataset.category;
        const sub  = row.dataset.subcategory;

        const show =
            name.includes(q) &&
            (catId === '' || cat === catId) &&
            (subId === '' || sub === subId);

        row.style.display = show ? '' : 'none';

        if (show) visible++;
    });

    document.getElementById('prod-empty').style.display = visible === 0 ? 'block' : 'none';
}

/* SEARCH */
document.getElementById('prod-search').addEventListener('input', filterProducts);

/* CATEGORY CHANGE */
document.getElementById('prod-cat-filter').addEventListener('change', function () {
    const catId = this.value;
    const subSelect = document.getElementById('prod-sub-filter');

    subSelect.value = "";

    Array.from(subSelect.options).forEach(opt => {
        if (opt.value === "") return;

        const optCat = opt.getAttribute('data-cat');

        opt.style.display =
            (catId === "" || optCat === catId) ? "" : "none";
    });

    filterProducts();
});

/* SUBCATEGORY */
document.getElementById('prod-sub-filter').addEventListener('change', filterProducts);

/* DELETE */
function confirmDelete(formId) {
    Swal.fire({
        title: 'Are you sure?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#6b7280',
        confirmButtonText: 'Yes delete'
    }).then(result => {
        if (result.isConfirmed) {
            document.getElementById(formId).submit();
        }
    });
}
</script>
@endpush