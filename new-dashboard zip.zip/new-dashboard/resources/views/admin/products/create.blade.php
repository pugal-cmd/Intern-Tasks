@extends('layouts.admin')

@section('title', isset($product) ? 'Edit Product' : 'Add Product')
@section('page-title', isset($product) ? 'Edit Product' : 'Add Product')
@section('page-subtitle', 'Fill in the product details below')

@section('content')
<div class="fade-in">

    <div class="breadcrumb">
        <a href="{{ route('admin.home') }}">Home</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <a href="{{ route('admin.products.index') }}">Products</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <span class="current">{{ isset($product) ? 'Edit' : 'Add' }}</span>
    </div>

    <div class="card" style="max-width: 820px;">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-{{ isset($product) ? 'pen' : 'plus' }}" style="color:var(--accent);margin-right:8px;"></i>
                {{ isset($product) ? 'Edit Product' : 'New Product' }}
            </h2>
        </div>

        <form action="{{ isset($product) ? route('admin.products.update', $product->id) : route('admin.products.store') }}"
              method="POST" enctype="multipart/form-data">

            @csrf
            @if(isset($product)) @method('PUT') @endif

            <!-- CATEGORY + SUBCATEGORY -->
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px;">
                <div class="form-group">
                    <label class="form-label">Category *</label>
                    <select name="category_id" id="catSelect" class="form-control" required>
                        <option value="">Select Category</option>
                        @foreach($categories as $cat)
                            <option value="{{ $cat->id }}"
                                {{ (isset($product) && $product->category_id == $cat->id) ? 'selected' : '' }}>
                                {{ $cat->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Subcategory *</label>
                    <select name="subcategory_id" id="subcatSelect" class="form-control" required>
                        <option value="">Select Subcategory</option>
                        @foreach($subcategories as $sub)
                            <option value="{{ $sub->id }}"
                                    data-cat="{{ $sub->category_id }}"
                                    {{ (isset($product) && $product->subcategory_id == $sub->id) ? 'selected' : '' }}>
                                {{ $sub->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <!-- PRODUCT NAME + AUTO SLUG -->
            <div class="form-group">
                <label class="form-label">Product Name *</label>
                <input type="text" name="name" id="productName" class="form-control"
                       value="{{ old('name', $product->name ?? '') }}" required
                       oninput="generateSlug(this.value)">
            </div>

            <div class="form-group">
                <label class="form-label">
                    URL Slug
                    <span style="font-weight:400; color:var(--text-muted); font-size:11px; margin-left:6px;">
                        (auto-generated, editable)
                    </span>
                </label>
                <div style="position:relative;">
                    <span style="position:absolute; left:14px; top:50%; transform:translateY(-50%); color:var(--text-muted); font-size:13px; pointer-events:none;">
                        /products/
                    </span>
                    <input type="text" name="slug" id="productSlug" class="form-control"
                           style="padding-left: 88px; font-family: monospace; font-size:13px;"
                           value="{{ old('slug', $product->slug ?? '') }}"
                           placeholder="auto-generated-slug">
                </div>
                <p style="font-size:11px; color:var(--text-muted); margin-top:5px;">
                    <i class="fas fa-info-circle"></i>
                    Edit the slug manually if needed. Only lowercase letters, numbers, and hyphens.
                </p>
            </div>

            <!-- PRICE -->
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px;">
                <div class="form-group">
                    <label class="form-label">MRP (₹) *</label>
                    <input type="number" name="mrp" class="form-control"
                           value="{{ old('mrp', $product->mrp ?? '') }}" required min="0" step="0.01">
                </div>
                <div class="form-group">
                    <label class="form-label">Selling Price (₹) *</label>
                    <input type="number" name="price" class="form-control"
                           value="{{ old('price', $product->price ?? '') }}" required min="0" step="0.01">
                </div>
            </div>

            <!-- IMAGE -->
            <div class="form-group">
                <label class="form-label">Product Image</label>

                {{-- Show current image when editing --}}
                @if(isset($product) && $product->image)
                <div style="margin-bottom:12px;">
                    <p style="font-size:12px; color:var(--text-muted); margin-bottom:6px;">Current Image:</p>
                    <img src="{{ asset('uploads/products/' . $product->image) }}"
                         id="currentProdImg"
                         style="width:100%; max-height:200px; object-fit:cover; border-radius:var(--radius-sm); border:1px solid var(--border);">
                </div>
                <label class="form-label">Replace Image (optional)</label>
                @endif

                <div class="upload-zone" onclick="document.getElementById('prodImg').click()">
                    <i class="fas fa-cloud-arrow-up"></i>
                    <p>{{ isset($product) && $product->image ? 'Click to replace image' : 'Click to upload image' }}</p>
                    <p><span>Any format</span> → stored as WebP ≤500KB</p>
                </div>

                <input type="file" id="prodImg" name="image" accept="image/*"
                       style="display:none;" onchange="previewProductImage(this)">

                <img id="prodPreview"
                     style="display:none; margin-top:10px; width:100%; border-radius:var(--radius-sm); max-height:200px; object-fit:cover;">
            </div>

            <!-- DESCRIPTION -->
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control"
                          style="min-height:110px;">{{ old('description', $product->description ?? '') }}</textarea>
            </div>

            <!-- BUTTONS -->
            <div style="display:flex; gap:12px; justify-content:flex-end; margin-top:24px;">
                <a href="{{ route('admin.products.index') }}" class="btn">Cancel</a>
                <button type="submit" class="btn btn-primary">
                    {{ isset($product) ? 'Update' : 'Save' }}
                </button>
            </div>

        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
/* ─── SLUG GENERATOR ─── */
function generateSlug(value) {
    const slug = value
        .toLowerCase()
        .trim()
        .replace(/[^\w\s-]/g, '')      // remove special chars
        .replace(/[\s_]+/g, '-')        // spaces/underscores → hyphens
        .replace(/--+/g, '-')           // collapse multiple hyphens
        .replace(/^-+|-+$/g, '');       // trim leading/trailing hyphens

    document.getElementById('productSlug').value = slug;
}

/* ─── IMAGE PREVIEW ─── */
function previewProductImage(input) {
    const prev = document.getElementById('prodPreview');
    const currentImg = document.getElementById('currentProdImg');

    if (input.files && input.files[0]) {
        prev.src = URL.createObjectURL(input.files[0]);
        prev.style.display = 'block';

        // Hide old image when new one selected
        if (currentImg) currentImg.style.opacity = '0.4';
    }
}

/* ─── CATEGORY → SUBCATEGORY ─── */
document.getElementById('catSelect').addEventListener('change', function () {
    const catId = this.value;
    const subSelect = document.getElementById('subcatSelect');
    subSelect.value = "";

    Array.from(subSelect.options).forEach(opt => {
        if (opt.value === "") return;
        opt.style.display = (catId === "" || opt.getAttribute('data-cat') === catId) ? "" : "none";
    });
});

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('catSelect').dispatchEvent(new Event('change'));
});
</script>
@endpush
