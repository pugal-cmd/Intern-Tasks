@extends('layouts.admin')
@section('title', 'Gallery')
@section('page-title', 'Gallery')
@section('page-subtitle', 'Manage your media gallery')

@section('content')
<div class="fade-in">
    <div class="breadcrumb">
        <a href="{{ route('admin.home') }}">Home</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <span class="current">Gallery</span>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><i class="fas fa-images" style="color:var(--accent);margin-right:8px;"></i>Gallery</h2>
            <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                <div style="position:relative;">
                    <i class="fas fa-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:13px;pointer-events:none;"></i>
                    <input type="text" id="gallery-search" class="form-control" placeholder="Search images..." style="padding-left:36px; width:220px;">
                </div>
                <button class="btn btn-primary" onclick="openModal('galleryModal')">
                    <i class="fas fa-plus"></i> Add Image
                </button>
            </div>
        </div>

        <div class="img-grid" id="gallery-grid">
            @forelse($gallery as $item)
            <div class="img-card fade-in" data-name="{{ strtolower($item->name) }}">
                <img src="{{ asset('uploads/gallery/' . $item->image) }}" alt="{{ $item->name }}" loading="lazy">
                <div class="img-card-body">
                    <div class="img-card-name">{{ $item->name }}</div>
                    <div style="font-size:11px; color:var(--text-muted); margin-bottom:10px;">
                        {{ $item->created_at->format('d M Y') }}
                    </div>
                    <div class="img-card-actions">
                        <button class="btn btn-success btn-sm" onclick="openEditModal({{ $item->id }}, '{{ $item->name }}')">
                            <i class="fas fa-pen"></i>
                        </button>
                        <form id="del-gal-{{ $item->id }}" action="{{ route('admin.gallery.destroy', $item->id) }}" method="POST">
                            @csrf @method('DELETE')
                            <button type="button" class="btn btn-danger btn-sm"
                                    onclick="deleteGallery('del-gal-{{ $item->id }}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            @empty
            <div style="grid-column:1/-1; text-align:center; padding:60px; color:var(--text-muted);">
                <i class="fas fa-images" style="font-size:48px; margin-bottom:16px; display:block;"></i>
                <p>No images in gallery yet.</p>
            </div>
            @endforelse
        </div>

        <div id="gallery-empty" style="display:none; text-align:center; padding:40px; color:var(--text-muted);">
            <i class="fas fa-search" style="font-size:32px; margin-bottom:12px; display:block;"></i>
            <p>No images match your search.</p>
        </div>

<div class="pagination">

    @if ($gallery->currentPage() > 1)
        <a href="{{ $gallery->previousPageUrl() }}" class="page-btn">
            &lt;
        </a>
    @endif

    @for ($i = 1; $i <= $gallery->lastPage(); $i++)
        <a href="{{ $gallery->url($i) }}"
           class="page-btn {{ $gallery->currentPage() == $i ? 'active' : '' }}">
            {{ $i }}
        </a>
    @endfor

    @if ($gallery->hasMorePages())
        <a href="{{ $gallery->nextPageUrl() }}" class="page-btn">
            &gt;
        </a>
    @endif

</div>    </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="galleryModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Add Gallery Image</h3>
            <button class="modal-close" onclick="closeModal('galleryModal')"><i class="fas fa-xmark"></i></button>
        </div>
        <form action="{{ route('admin.gallery.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label class="form-label">Image Name <span style="color:var(--danger)">*</span></label>
                <input type="text" name="name" class="form-control" placeholder="Image title" required>
            </div>
            <div class="form-group">
                <label class="form-label">Image <span style="color:var(--danger)">*</span></label>
                <div class="upload-zone" onclick="document.getElementById('galImg').click()">
                    <i class="fas fa-cloud-arrow-up"></i>
                    <p>Upload image</p>
                    <p>Select multiple images at once</p>
                    <p><span>Any format</span> → stored as WebP ≤500KB</p>
                </div>
                <input type="file" id="galImg" name="images[]" accept="image/*" multiple style="display:none;" required onchange="previewMultiple(this)">
                <div id="preview-container" style="display:flex; flex-wrap:wrap; gap:10px; margin-top:10px;"></div>
            </div>
            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button type="button" class="btn" onclick="closeModal('galleryModal')" style="background:var(--bg-main); color:var(--text-secondary);">Cancel</button>
                <button type="submit" class="btn btn-primary">Upload Image</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editGalleryModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Edit Gallery Item</h3>
            <button class="modal-close" onclick="closeModal('editGalleryModal')"><i class="fas fa-xmark"></i></button>
        </div>
        <form id="editGalleryForm" method="POST" enctype="multipart/form-data">
            @csrf @method('PUT')
            <div class="form-group">
                <label class="form-label">Image Name</label>
                <input type="text" id="editGalName" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Replace Image (optional)</label>
                <div class="upload-zone" onclick="document.getElementById('editGalImg').click()">
                    <i class="fas fa-cloud-arrow-up"></i>
                    <p>Replace image</p>
                </div>
                <input type="file" id="editGalImg" name="image" accept="image/*" style="display:none;" onchange="previewSingle(this,'editGalPreview')">
                <img id="editGalPreview" style="display:none; margin-top:10px; width:100%; border-radius:var(--radius-sm); max-height:150px; object-fit:cover;">
            </div>
            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button type="button" class="btn" onclick="closeModal('editGalleryModal')" style="background:var(--bg-main); color:var(--text-secondary);">Cancel</button>
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function previewMultiple(input) {
    const container = document.getElementById('preview-container');
    container.innerHTML = '';
    if (input.files) {
        Array.from(input.files).forEach(file => {
            const img = document.createElement('img');
            img.src = URL.createObjectURL(file);
            img.style.cssText = 'width:120px;height:120px;object-fit:cover;border-radius:8px;border:1px solid #ddd;';
            container.appendChild(img);
        });
    }
}

function previewSingle(input, previewId) {
    const prev = document.getElementById(previewId);
    if (input.files && input.files[0]) {
        prev.src = URL.createObjectURL(input.files[0]);
        prev.style.display = 'block';
    }
}

function openEditModal(id, name) {
    document.getElementById('editGalName').value = name;
    document.getElementById('editGalleryForm').action = `/admin/gallery/${id}`;
    openModal('editGalleryModal');
}

function deleteGallery(formId) {
    Swal.fire({
        title: 'Delete Image?',
        text: "This action cannot be undone!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById(formId).submit();
        }
    });
}

// Auto search for gallery grid
document.getElementById('gallery-search').addEventListener('input', function () {
    const q = this.value.toLowerCase().trim();
    const cards = document.querySelectorAll('#gallery-grid .img-card');
    let visible = 0;
    cards.forEach(card => {
        const name = card.getAttribute('data-name') || '';
        const show = name.includes(q);
        card.style.display = show ? '' : 'none';
        if (show) visible++;
    });
    document.getElementById('gallery-empty').style.display = visible === 0 ? 'block' : 'none';
});
</script>
@endpush