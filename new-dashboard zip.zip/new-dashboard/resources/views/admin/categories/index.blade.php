@extends('layouts.admin')

@section('title', 'Categories')
@section('page-title', 'Categories')
@section('page-subtitle', 'Manage product categories')

@section('content')
<div class="fade-in">
    <div class="breadcrumb">
        <a href="{{ route('admin.home') }}">Home</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <span class="current">Categories</span>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-layer-group" style="color:var(--accent);margin-right:8px;"></i>
                All Categories
            </h2>

           <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
    <input type="text"
           id="catSearch"
           class="form-control"
           placeholder="Search category..."
           style="width:220px; max-width:100%;">

    <button class="btn btn-primary" onclick="openModal('catModal')">
        <i class="fas fa-plus"></i> Add Category
    </button>
</div>
        </div>

        <div class="img-grid" id="catGrid">
            @forelse($categories as $cat)
            <div class="img-card fade-in cat-item" data-name="{{ strtolower($cat->name) }}">

                @if($cat->image)
                    <img src="{{ asset('uploads/categories/' . $cat->image) }}" alt="{{ $cat->name }}">
                @else
                    <div style="aspect-ratio:4/3; background: var(--bg-main); display:flex; align-items:center; justify-content:center;">
                        <i class="fas fa-image" style="font-size:32px; color:var(--text-muted);"></i>
                    </div>
                @endif

                <div class="img-card-body">
                    <div class="img-card-name">{{ $cat->name }}</div>
                    <div style="font-size:11px; color:var(--text-muted); margin-bottom:10px;">
                        ID: #{{ $cat->id }}
                    </div>

                    <div class="img-card-actions" style="display:flex; justify-content:space-between;">
                        <button class="btn btn-success btn-sm"
                                onclick="openEditModal(
                                    {{ $cat->id }},
                                    '{{ addslashes($cat->name) }}',
                                    '{{ $cat->image ? asset('uploads/categories/' . $cat->image) : '' }}'
                                )">
                            <i class="fas fa-pen"></i>
                        </button>

                        <form id="del-cat-{{ $cat->id }}"
                              action="{{ route('admin.categories.destroy', $cat->id) }}"
                              method="POST">
                            @csrf @method('DELETE')
                            <button type="button"
                                    class="btn btn-danger btn-sm"
                                    onclick="confirmDelete('del-cat-{{ $cat->id }}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            @empty
            <div style="grid-column:1/-1; text-align:center; padding:60px; color:var(--text-muted);">
                <i class="fas fa-layer-group" style="font-size:48px;"></i>
                <p>No categories found</p>
            </div>
            @endforelse
        </div>

        <div class="pagination">{{ $categories->links() }}</div>
    </div>
</div>

<!-- ADD MODAL -->
<div class="modal-overlay" id="catModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Add Category</h3>
            <button class="modal-close" onclick="closeModal('catModal')">
                <i class="fas fa-xmark"></i>
            </button>
        </div>

        <form action="{{ route('admin.categories.store') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="form-group">
                <label class="form-label">Category Name *</label>
                <input type="text" name="name" class="form-control" required>
            </div>

            <div class="form-group">
                <label class="form-label">Image</label>
                <div class="upload-zone" onclick="document.getElementById('addCatImg').click()">
                    <i class="fas fa-cloud-arrow-up"></i>
                    <p>Click to upload image</p>
                    <p><span>Any format</span> → stored as WebP</p>
                </div>
                <input type="file" id="addCatImg" name="image" accept="image/*"
                       style="display:none;" onchange="previewSingle(this, 'addCatPreview')">
                <img id="addCatPreview"
                     style="display:none; margin-top:10px; width:100%; border-radius:var(--radius-sm); max-height:160px; object-fit:cover;">
            </div>

            <div style="display:flex; justify-content:flex-end; gap:10px;">
                <button type="button" class="btn" onclick="closeModal('catModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- EDIT MODAL -->
<div class="modal-overlay" id="editCatModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Edit Category</h3>
            <button class="modal-close" onclick="closeModal('editCatModal')">
                <i class="fas fa-xmark"></i>
            </button>
        </div>

        <form id="editCatForm" method="POST" enctype="multipart/form-data">
            @csrf @method('PUT')

            <div class="form-group">
                <label class="form-label">Category Name *</label>
                <input type="text" id="editCatName" name="name" class="form-control" required>
            </div>

            <div class="form-group">
                <label class="form-label">Current Image</label>
                <img id="editCatCurrentImg"
                     style="display:none; width:100%; border-radius:var(--radius-sm); max-height:160px; object-fit:cover; margin-bottom:10px; border:1px solid var(--border);">

                <label class="form-label" style="margin-top:4px;">Replace Image (optional)</label>
                <div class="upload-zone" onclick="document.getElementById('editCatImg').click()">
                    <i class="fas fa-cloud-arrow-up"></i>
                    <p>Click to replace image</p>
                </div>
                <input type="file" id="editCatImg" name="image" accept="image/*"
                       style="display:none;" onchange="previewSingle(this, 'editCatNewPreview')">
                <img id="editCatNewPreview"
                     style="display:none; margin-top:10px; width:100%; border-radius:var(--radius-sm); max-height:160px; object-fit:cover;">
            </div>

            <div style="display:flex; justify-content:flex-end; gap:10px;">
                <button type="button" class="btn" onclick="closeModal('editCatModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function previewSingle(input, previewId) {
    const prev = document.getElementById(previewId);
    if (input.files && input.files[0]) {
        prev.src = URL.createObjectURL(input.files[0]);
        prev.style.display = 'block';
    }
}

function openEditModal(id, name, imageUrl) {
    document.getElementById('editCatName').value = name;
    document.getElementById('editCatForm').action = `/admin/categories/${id}`;

    const currentImg = document.getElementById('editCatCurrentImg');
    const newPreview = document.getElementById('editCatNewPreview');
    const fileInput  = document.getElementById('editCatImg');

    // Reset new preview
    newPreview.style.display = 'none';
    newPreview.src = '';
    fileInput.value = '';

    // Show current image if exists
    if (imageUrl) {
        currentImg.src = imageUrl;
        currentImg.style.display = 'block';
    } else {
        currentImg.style.display = 'none';
    }

    openModal('editCatModal');
}

function confirmDelete(formId) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This category will be deleted!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#6b7280',
        confirmButtonText: 'Yes, delete it!',
        background: '#ffffff',
        color: '#111827',
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById(formId).submit();
        }
    });
}

document.getElementById('catSearch').addEventListener('input', function () {
    let value = this.value.toLowerCase();
    document.querySelectorAll('.cat-item').forEach(item => {
        item.style.display = item.getAttribute('data-name').includes(value) ? '' : 'none';
    });
});
</script>
@endpush
