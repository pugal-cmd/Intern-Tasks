@extends('layouts.admin')
@section('title', 'Blogs')
@section('page-title', 'Blog Posts')
@section('page-subtitle', 'Manage your blog content')

@section('content')
<div class="fade-in">
    <div class="breadcrumb">
        <a href="{{ route('admin.home') }}">Home</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <span class="current">Blogs</span>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title"><i class="fas fa-pen-to-square" style="color:var(--accent);margin-right:8px;"></i>Blog Posts</h2>
            <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                <div style="position:relative;">
                    <i class="fas fa-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:13px;pointer-events:none;"></i>
                    <input type="text" id="blog-search" class="form-control" placeholder="Search blogs..." style="padding-left:36px; width:220px;">
                </div>
                <a href="{{ route('admin.blogs.create') }}" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add Blog
                </a>
            </div>
        </div>

        <div class="table-wrap">
            <table id="blog-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Date</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($blogs as $i => $blog)
                    <tr data-name="{{ strtolower($blog->title) }}">
                        <td>{{ $blogs->firstItem() + $i }}</td>
                        <td>
                            @if($blog->image)
                                <img src="{{ asset('uploads/blogs/' . $blog->image) }}" class="td-img" alt="">
                            @else
                                <div class="td-img" style="background:var(--bg-main); display:flex; align-items:center; justify-content:center;">
                                    <i class="fas fa-image" style="color:var(--text-muted);"></i>
                                </div>
                            @endif
                        </td>
                        <td style="color:var(--text-primary); font-weight:500; max-width:280px;">
                            {{ Str::limit($blog->title, 60) }}
                        </td>
                        <td>
                            <span class="badge badge-purple">{{ \Carbon\Carbon::parse($blog->date)->format('d M Y') }}</span>
                        </td>
                        <td>{{ $blog->created_at->format('d M Y') }}</td>
                        <td>
                            <div style="display:flex; gap:6px;">
                                <a href="{{ route('admin.blogs.edit', ['blog' => $blog->id]) }}" class="btn btn-success btn-sm">
                                    <i class="fas fa-pen"></i>
                                </a>
                                <form id="del-blog-{{ $blog->id }}" action="{{ route('admin.blogs.destroy', $blog->id) }}" method="POST">
                                    @csrf @method('DELETE')
                                    <button type="button" class="btn btn-danger btn-sm"
                                            onclick="confirmDelete('del-blog-{{ $blog->id }}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align:center; padding:50px; color:var(--text-muted);">
                            <i class="fas fa-pen-to-square" style="font-size:36px; margin-bottom:12px; display:block;"></i>
                            No blog posts yet.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div id="blog-empty" style="display:none; text-align:center; padding:40px; color:var(--text-muted);">
            <i class="fas fa-search" style="font-size:32px; margin-bottom:12px; display:block;"></i>
            <p>No blogs match your search.</p>
        </div>

        <div class="pagination">{{ $blogs->links() }}</div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.getElementById('blog-search').addEventListener('input', function () {
    const q = this.value.toLowerCase().trim();
    const rows = document.querySelectorAll('#blog-table tbody tr[data-name]');
    let visible = 0;
    rows.forEach(row => {
        const show = row.getAttribute('data-name').includes(q);
        row.style.display = show ? '' : 'none';
        if (show) visible++;
    });
    document.getElementById('blog-empty').style.display = visible === 0 ? 'block' : 'none';
});
</script>
@endpush