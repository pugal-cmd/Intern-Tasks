@extends('layouts.admin')
@section('title', 'Subcategories')
@section('page-title', 'Subcategories')
@section('page-subtitle', 'Manage subcategories under each category')

@section('content')
<div class="fade-in">
    <div class="breadcrumb">
        <a href="{{ route('admin.home') }}">Home</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <a href="{{ route('admin.categories.index') }}">Categories</a>
        <span class="sep"><i class="fas fa-chevron-right" style="font-size:10px;"></i></span>
        <span class="current">Subcategories</span>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-sitemap" style="color:var(--accent);margin-right:8px;"></i>
                All Subcategories
            </h2>
            <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                <div style="position:relative;">
                    <i class="fas fa-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:13px;pointer-events:none;"></i>
                    <input type="text" id="sub-search" class="form-control" placeholder="Search subcategories..." style="padding-left:36px; width:220px;">
                </div>
                <select id="sub-cat-filter" class="form-control" style="width:180px;">
                    <option value="">All Categories</option>
                    @foreach($categories as $cat)
                        <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                    @endforeach
                </select>
                <button class="btn btn-primary" onclick="openModal('subcatModal')">
                    <i class="fas fa-plus"></i> Add Subcategory
                </button>
            </div>
        </div>

        <div class="table-wrap">
            <table id="sub-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Cat ID</th>
                        <th>Category</th>
                        <th>Subcategory Name</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($subcategories as $i => $sub)
                    <tr data-name="{{ strtolower($sub->name) }}" data-category="{{ $sub->category_id }}">
                        <td>{{ $subcategories->firstItem() + $i }}</td>
                        <td><span class="badge badge-purple">#{{ $sub->category_id }}</span></td>
                        <td style="font-weight:500;">{{ $sub->category->name ?? '—' }}</td>
                        <td>{{ $sub->name }}</td>
                        <td>{{ $sub->created_at->format('d M Y') }}</td>
                        <td>
                            <div style="display:flex; gap:6px; justify-content:center;">
                                <button class="btn btn-success btn-sm"
                                    onclick="openEditModal({{ $sub->id }}, {{ $sub->category_id }}, '{{ $sub->name }}')">
                                    <i class="fas fa-pen"></i>
                                </button>
                                <form id="del-sub-{{ $sub->id }}"
                                      action="{{ route('admin.subcategories.destroy', $sub->id) }}"
                                      method="POST" style="display:inline;">
                                    @csrf @method('DELETE')
                                    <button type="button" class="btn btn-danger btn-sm"
                                            onclick="confirmDelete('del-sub-{{ $sub->id }}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align:center; padding:50px;">
                            <i class="fas fa-sitemap" style="font-size:36px; margin-bottom:12px; display:block;"></i>
                            No subcategories found.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div id="sub-empty" style="display:none; text-align:center; padding:40px; color:var(--text-muted);">
            <i class="fas fa-search" style="font-size:32px; margin-bottom:12px; display:block;"></i>
            <p>No subcategories match your search.</p>
        </div>

        <div class="pagination">{{ $subcategories->links() }}</div>
    </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="subcatModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Add Subcategory</h3>
            <button class="modal-close" onclick="closeModal('subcatModal')"><i class="fas fa-xmark"></i></button>
        </div>
        <form action="{{ route('admin.subcategories.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label class="form-label">Parent Category</label>
                <select name="category_id" class="form-control" required>
                    <option value="">Select Category</option>
                    @foreach($categories as $cat)
                        <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Subcategory Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button type="button" class="btn" onclick="closeModal('subcatModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editSubcatModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Edit Subcategory</h3>
            <button class="modal-close" onclick="closeModal('editSubcatModal')"><i class="fas fa-xmark"></i></button>
        </div>
        <form id="editSubcatForm" method="POST">
            @csrf @method('PUT')
            <div class="form-group">
                <label class="form-label">Parent Category</label>
                <select id="editSubcatCatId" name="category_id" class="form-control" required>
                    @foreach($categories as $cat)
                        <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Subcategory Name</label>
                <input type="text" id="editSubcatName" name="name" class="form-control" required>
            </div>
            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button type="button" class="btn" onclick="closeModal('editSubcatModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function openEditModal(id, catId, name) {
    document.getElementById('editSubcatName').value = name;
    document.getElementById('editSubcatCatId').value = catId;
    document.getElementById('editSubcatForm').action = `/admin/subcategories/${id}`;
    openModal('editSubcatModal');
}

// Auto search + category filter
function filterSubcategories() {
    const q = document.getElementById('sub-search').value.toLowerCase().trim();
    const catId = document.getElementById('sub-cat-filter').value;
    const rows = document.querySelectorAll('#sub-table tbody tr[data-name]');
    let visible = 0;
    rows.forEach(row => {
        const name = row.getAttribute('data-name') || '';
        const cat  = row.getAttribute('data-category') || '';
        const matchSearch = name.includes(q);
        const matchCat    = catId === '' || cat === catId;
        const show = matchSearch && matchCat;
        row.style.display = show ? '' : 'none';
        if (show) visible++;
    });
    document.getElementById('sub-empty').style.display = visible === 0 ? 'block' : 'none';
}

document.getElementById('sub-search').addEventListener('input', filterSubcategories);
document.getElementById('sub-cat-filter').addEventListener('change', filterSubcategories);
</script>
@endpush