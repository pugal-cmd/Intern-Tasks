<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') — Admin Panel</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="https://cdn-icons-png.flaticon.com/512/2721/2721287.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-lite.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <style>
        :root {
            --sidebar-w: 260px;
            --sidebar-collapsed: 72px;
            --bg-main: #ffffff;
            --bg-sidebar: #ffffff;
            --bg-card: #ffffff;
            --bg-card-hover: #95bfe8;
            --accent: #8b5cf6;
            --accent-soft: rgba(139, 92, 246, 0.10);
            --accent2: #a78bfa;
            --text-primary: #0f172a;
            --text-secondary: #475569;
            --text-muted: #94a3b8;
            --border: rgba(15, 23, 42, 0.08);
            --border-active: rgba(37, 99, 235, 0.35);
            --success: #16a34a;
            --warning: #f59e0b;
            --danger: #dc2626;
            --radius: 14px;
            --radius-sm: 8px;
            --shadow-soft: 0 4px 12px rgba(139, 92, 246, 0.18);
            --transition: 0.28s cubic-bezier(0.4,0,0.2,1);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--bg-main);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            overflow-x: hidden;
            overflow-y: auto;
        }

        /* ─── SIDEBAR ─── */
        .sidebar {
    width: var(--sidebar-w);
    height: 100vh;
    background: var(--bg-sidebar);
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 100;
    transition: width var(--transition);

    overflow-y: auto;
    overflow-x: hidden;
}
        .sidebar.collapsed { width: var(--sidebar-collapsed); }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            border-bottom: 1px solid var(--border);
            min-height: 72px;
            overflow: hidden;
            white-space: nowrap;
        }

        .swal-modern {
            border-radius: 16px !important;
            box-shadow: 0 20px 60px rgba(0,0,0,0.12) !important;
            font-family: 'DM Sans', sans-serif;
            padding: 20px !important;
        }

        .logo-icon {
            width: 36px; height: 36px;
            background: var(--accent);
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
            box-shadow: 0 0 20px rgba(108,99,255,0.5);
        }
        .logo-text {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 18px;
            font-weight: 700;
            color: var(--text-primary);
            letter-spacing: -0.3px;
            transition: opacity var(--transition);
        }
        .sidebar.collapsed .logo-text { opacity: 0; width: 0; }

        .sidebar-toggle {
            position: absolute;
            right: 12px; top: 28px;
            width: 28px; height: 28px;
            background: var(--accent);
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            color: #fff;
            font-size: 11px;
            box-shadow: 0 2px 12px rgba(108,99,255,0.6);
            z-index: 10;
            transition: transform var(--transition);
        }
        .sidebar.collapsed .sidebar-toggle { transform: rotate(180deg); }

        .sidebar-nav {
            padding: 16px 12px;
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
        }
        .sidebar-nav::-webkit-scrollbar { width: 3px; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: var(--text-muted); border-radius: 3px; }

        .nav-label {
            font-size: 10px;
            font-weight: 600;
            letter-spacing: 1.2px;
            color: var(--text-muted);
            text-transform: uppercase;
            padding: 4px 10px 4.5px;
            white-space: nowrap;
            overflow: hidden;
            transition: opacity var(--transition);
        }
        .sidebar.collapsed .nav-label { opacity: 0; }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 11px 10px;
            border-radius: var(--radius-sm);
            text-decoration: none;
            color: var(--text-secondary);
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 2px;
            white-space: nowrap;
            position: relative;
            transition: all 0.2s ease;
            overflow: hidden;
        }
        .nav-item:hover, .nav-item.active {
            color: var(--text-primary);
            background: var(--accent-soft);
        }
        .nav-item.active {
            color: var(--accent);
            border-left: 3px solid var(--accent);
        }
        .nav-item .nav-icon {
            width: 36px; height: 36px;
            border-radius: 9px;
            display: flex; align-items: center; justify-content: center;
            font-size: 15px;
            flex-shrink: 0;
            background: rgba(255,255,255,0.04);
            transition: background 0.2s;
        }
        .nav-item:hover .nav-icon,
        .nav-item.active .nav-icon {
            background: var(--accent-soft);
            color: var(--accent);
        }
        .nav-item .nav-text {
            font-size: 14px;
            transition: opacity var(--transition), width var(--transition);
        }
        .sidebar.collapsed .nav-text { opacity: 0; width: 0; }
        .sidebar.collapsed .nav-badge { opacity: 0; }

        .sidebar.collapsed .nav-item::after {
            content: attr(data-tooltip);
            position: absolute;
            left: calc(var(--sidebar-collapsed) - 4px);
            background: #1f2235;
            color: var(--text-primary);
            font-size: 13px;
            padding: 6px 12px;
            border-radius: 8px;
            white-space: nowrap;
            pointer-events: none;
            opacity: 0;
            border: 1px solid var(--border);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.25);
            transition: opacity 0.15s;
        }
        .sidebar.collapsed .nav-item:hover::after { opacity: 1; }

        .card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 24px;
            box-shadow: 0 6px 18px rgba(139, 92, 246, 0.14) !important;
        }

        .nav-badge {
            margin-left: auto;
            background: var(--accent);
            color: #fff;
            font-size: 10px;
            font-weight: 700;
            padding: 2px 7px;
            border-radius: 20px;
            transition: opacity var(--transition);
        }

        /* ─── MAIN CONTENT ─── */
        .main-wrap {
            margin-left: var(--sidebar-w);
            flex: 1;
            min-height: 100vh;
            transition: margin-left var(--transition);
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }
        body.sidebar-collapsed .main-wrap { margin-left: var(--sidebar-collapsed); }

        /* ─── TOPBAR ─── */
        .topbar {
            height: 72px;
            background: var(--bg-sidebar);
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 28px;
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .topbar-left h1 {
            padding: 10px 0 6px;
            font-family: 'Space Grotesk', sans-serif;
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            /* ── TASK 4: Remove margin-bottom gap under heading ── */
            line-height: 1.2;
        }
        .topbar-left p {
            padding: 0 0 16px;
            font-size: 12px;
            color: var(--text-secondary);
            /* ── TASK 4: Consistent small top margin for subtitle ── */
            margin-top: 3px;
            line-height: 1;
        }
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .topbar-btn {
            width: 38px; height: 38px;
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            color: var(--text-secondary);
            cursor: pointer;
            font-size: 15px;
            transition: all 0.2s;
            text-decoration: none;
            outline: none;
        }
        .topbar-btn:hover { background: var(--accent-soft); color: var(--accent); border-color: var(--border-active); }

        .avatar {
            width: 38px; height: 38px;
            background: linear-gradient(135deg, var(--accent), var(--accent2));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            color: #fff;
        }

        /* ─── PAGE CONTENT ─── */
        .page-content {
            /* ── TASK 4: Consistent padding on all pages ── */
            padding: 28px;
            flex: 1;
        }

        /* ─── CARDS ─── */
        .card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .card-title {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 16px;
            font-weight: 600;
        }

        /* ─── BUTTONS ─── */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 9px 18px;
            border-radius: var(--radius-sm);
            border: none;
            cursor: pointer;
            font-family: 'DM Sans', sans-serif;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s;
        }
        .btn-primary { background: var(--accent); color: #fff; box-shadow: 0 4px 15px rgba(108,99,255,0.35); }
        .btn-primary:hover { background: #7c74ff; transform: translateY(-1px); box-shadow: 0 6px 20px rgba(108,99,255,0.45); color: #fff; }
        .btn-danger { background: rgba(248,113,113,0.15); color: var(--danger); border: 1px solid rgba(248,113,113,0.2); }
        .btn-danger:hover { background: rgba(248,113,113,0.25); }
        .btn-success { background: rgba(74,222,128,0.15); color: var(--success); border: 1px solid rgba(74,222,128,0.2); }
        .btn-success:hover { background: rgba(74,222,128,0.25); }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        .btn-icon { width: 32px; height: 32px; padding: 0; justify-content: center; border-radius: var(--radius-sm); }

        /* ─── TABLE ─── */
        .table-wrap {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        table { width: 100%; }
        table th, table td { text-align: center; vertical-align: middle; }
        html, body { overflow-x: hidden; overscroll-behavior: none; height: 100%; }
        table { min-width: 700px; }
        thead tr { border-bottom: 1px solid var(--border); }
        th { font-size: 11px; font-weight: 600; letter-spacing: 0.8px; text-transform: uppercase; color: var(--text-muted); padding: 12px 16px; text-align: left; }
        td { padding: 14px 16px; font-size: 13px; color: var(--text-secondary); border-bottom: 1px solid var(--border); vertical-align: middle; }
        tbody tr { transition: background 0.15s; }
        tbody tr:hover { background: var(--bg-card-hover); }
        tbody tr:last-child td { border-bottom: none; }

        .td-img { width: 44px; height: 44px; border-radius: 8px; object-fit: cover; border: 1px solid var(--border); }

        /* ─── BADGES ─── */
        .badge { display: inline-flex; align-items: center; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
        .badge-purple { background: var(--accent-soft); color: var(--accent); }
        .badge-green { background: rgba(74,222,128,0.1); color: var(--success); }

        /* ─── FORMS ─── */
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-size: 12px; font-weight: 600; color: var(--text-secondary); margin-bottom: 7px; letter-spacing: 0.3px; }
        .form-control {
            width: 100%;
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 10px 14px;
            color: #111827;
            font-family: 'DM Sans', sans-serif;
            font-size: 14px;
            transition: all 0.2s ease;
        }
        .form-control:focus { outline: none; border-color: var(--accent); background: #ffffff; box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15); }
        select.form-control { cursor: pointer; }
        select.form-control option { background: #ffffff; color: #111827; }
        .form-control:hover { border-color: #cbd5e1; }

        /* ─── PLACEHOLDERS ─── */
        .form-control::placeholder { color: var(--text-muted); font-size: 13px; font-style: normal; opacity: 1; }
        .form-control::-webkit-input-placeholder { color: var(--text-muted); opacity: 1; }
        .form-control::-moz-placeholder { color: var(--text-muted); opacity: 1; }
        .form-control:-ms-input-placeholder { color: var(--text-muted); opacity: 1; }
        select.form-control:invalid,
        select.form-control option[value=""] { color: var(--text-muted); }

        /* ─── ALERT ─── */
        .alert { padding: 12px 16px; border-radius: var(--radius-sm); font-size: 13px; margin-bottom: 16px; }
        .alert-success { background: rgba(74,222,128,0.1); border: 1px solid rgba(74,222,128,0.2); color: var(--success); }
        .alert-danger { background: rgba(248,113,113,0.1); border: 1px solid rgba(248,113,113,0.2); color: var(--danger); }

        /* ─── STAT CARDS ─── */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 18px; margin-bottom: 28px; }
        .stat-card { background: var(--bg-card); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; position: relative; overflow: hidden; transition: transform 0.2s, box-shadow 0.2s; }
        .stat-card:hover { transform: translateY(-2px); box-shadow: 0 12px 40px rgba(139, 92, 246, 0.18); }
        .stat-card::before { content: ''; position: absolute; top: -30px; right: -30px; width: 100px; height: 100px; border-radius: 50%; opacity: 0.08; }
        .stat-card:nth-child(1)::before { background: var(--accent); }
        .stat-card:nth-child(2)::before { background: #06b6d4; }
        .stat-card:nth-child(3)::before { background: var(--success); }
        .stat-card:nth-child(4)::before { background: var(--warning); }
        .stat-card:nth-child(5)::before { background: var(--accent2); }
        .stat-card:nth-child(6)::before { background: #f43f5e; }
        .stat-icon { width: 42px; height: 42px; border-radius: 11px; display: flex; align-items: center; justify-content: center; font-size: 18px; margin-bottom: 14px; }
        .stat-value { font-family: 'Space Grotesk', sans-serif; font-size: 28px; font-weight: 700; line-height: 1; margin-bottom: 4px; }
        .stat-label { font-size: 12px; color: var(--text-muted); font-weight: 500; }

        /* ─── IMAGE GRID ─── */
        .img-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 16px; }
        .img-card { background: var(--bg-card); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; transition: transform 0.2s; }
        .img-card:hover { transform: translateY(-3px); }
        .img-card img { width: 100%; aspect-ratio: 4/3; object-fit: cover; display: block; }
        .img-card-body { padding: 12px 14px; }
        .img-card-name { font-size: 13px; font-weight: 600; color: var(--text-primary); margin-bottom: 8px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .img-card-actions { display: flex; gap: 6px; }

        /* ─── MODAL ─── */
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 1000; display: none; align-items: center; justify-content: center; backdrop-filter: blur(4px); }
        .modal-overlay.open { display: flex; }
        .modal { background: var(--bg-card); border: 1px solid var(--border); border-radius: var(--radius); width: 100%; max-width: 560px; max-height: 90vh; overflow-y: auto; padding: 28px; box-shadow: 0 24px 60px rgba(139, 92, 246, 0.18); }
        .modal-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; }
        .modal-title { font-family: 'Space Grotesk', sans-serif; font-size: 18px; font-weight: 700; }
        .modal-close { background: none; border: none; color: var(--text-muted); font-size: 20px; cursor: pointer; }
        .modal-close:hover { color: var(--text-primary); }

        /* ─── UPLOAD ZONE ─── */
        .upload-zone { border: 2px dashed var(--border); border-radius: var(--radius-sm); padding: 28px; text-align: center; cursor: pointer; transition: all 0.2s; }
        .upload-zone:hover { border-color: var(--accent); background: var(--accent-soft); }
        .upload-zone i { font-size: 28px; color: var(--text-muted); margin-bottom: 8px; }
        .upload-zone p { font-size: 13px; color: var(--text-secondary); }
        .upload-zone span { color: var(--accent); font-weight: 600; }

        /* ─── PAGINATION ─── */
        .pagination { display: flex; justify-content: center; align-items: center; gap: 8px; margin-top: 30px; }
        .page-btn { width: 38px; height: 38px; border-radius: 8px; border: 1px solid var(--border); display: flex; align-items: center; justify-content: center; text-decoration: none; color: var(--text-primary); background: var(--bg-card); font-weight: 600; transition: 0.2s; }
        .page-btn:hover { background: var(--accent-soft); color: var(--accent); }
        .page-btn.active { background: var(--accent); color: #fff; border-color: var(--accent); }

        /* ─── BREADCRUMB ─── */
        .breadcrumb { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-muted); margin-bottom: 20px; }
        .breadcrumb a { color: var(--text-muted); text-decoration: none; }
        .breadcrumb a:hover { color: var(--accent); }
        .breadcrumb .sep { color: var(--text-muted); }
        .breadcrumb .current { color: var(--text-primary); }

        /* ─── MOBILE TOGGLE ─── */
        .mobile-toggle { display: none; width: 38px; height: 38px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 10px; align-items: center; justify-content: center; color: var(--text-secondary); cursor: pointer; font-size: 18px; transition: all 0.2s; flex-shrink: 0; }
        .mobile-toggle:hover { background: var(--accent-soft); color: var(--accent); border-color: var(--border-active); }

        /* ─── BELL SHAKE ─── */
        @keyframes bellShake {
            0%,100% { transform: rotate(0); }
            10%      { transform: rotate(-18deg); }
            20%      { transform: rotate(16deg); }
            30%      { transform: rotate(-14deg); }
            40%      { transform: rotate(12deg); }
            50%      { transform: rotate(-10deg); }
            60%      { transform: rotate(8deg); }
            70%      { transform: rotate(-6deg); }
            80%      { transform: rotate(4deg); }
            90%      { transform: rotate(-2deg); }
        }
        .bell-shake { animation: bellShake 0.7s ease; }

        /* ─── GEAR TILT ─── */
        @keyframes gearTilt {
            0%   { transform: rotate(0); }
            30%  { transform: rotate(22deg); }
            60%  { transform: rotate(-10deg); }
            80%  { transform: rotate(8deg); }
            100% { transform: rotate(0); }
        }
        .gear-tilt { animation: gearTilt 0.5s ease; }

        /* ─── DROPDOWN PANEL ─── */
        .notif-dropdown {
            position: absolute;
            top: calc(100% + 10px);
            right: 0;
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 8px;
            min-width: 220px;
            box-shadow: 0 8px 32px rgba(139,92,246,0.14);
            z-index: 300;
            opacity: 0;
            transform: translateY(-6px);
            pointer-events: none;
            transition: opacity 0.18s, transform 0.18s;
        }
        .notif-dropdown.open { opacity: 1; transform: translateY(0); pointer-events: all; }
        .notif-dropdown-title { font-size: 10px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; color: var(--text-muted); padding: 4px 10px 10px; }
        .notif-empty { display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 16px 10px 14px; }
        .notif-empty-icon { width: 44px; height: 44px; border-radius: 50%; background: var(--accent-soft); display: flex; align-items: center; justify-content: center; font-size: 18px; color: var(--accent); }
        .notif-empty p { font-size: 12px; color: var(--text-muted); text-align: center; line-height: 1.6; }

        /* ─── THEME OPTIONS ─── */
        .theme-option { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 10px; cursor: pointer; color: var(--text-secondary); font-size: 13px; transition: background 0.15s; border: none; background: none; width: 100%; text-align: left; font-family: 'DM Sans', sans-serif; }
        .theme-option:hover { background: var(--accent-soft); }
        .theme-option.active { background: var(--accent-soft); color: var(--accent); }
        .theme-opt-icon { width: 32px; height: 32px; border-radius: 8px; background: rgba(139,92,246,0.08); display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0; }
        .theme-opt-label { font-size: 13px; font-weight: 600; color: var(--text-primary); }
        .theme-opt-sub { font-size: 11px; color: var(--text-muted); margin-top: 1px; }
        .theme-check { margin-left: auto; font-size: 13px; color: var(--accent); opacity: 0; }
        .theme-option.active .theme-check { opacity: 1; }

        /* ─── DARK THEME ─── */
        body.dark-theme {
            --bg-main: #0f172a;
            --bg-sidebar: #1e293b;
            --bg-card: #1e293b;
            --text-primary: #f1f5f9;
            --text-secondary: #94a3b8;
            --text-muted: #475569;
            --border: rgba(255,255,255,0.08);
            --border-active: rgba(139,92,246,0.4);
            --bg-card-hover: #2d3f55;
        }
        body.dark-theme .form-control { background: #0f172a; border-color: rgba(255,255,255,0.1); color: #f1f5f9; }
        body.dark-theme .note-toolbar { background: #1e293b !important; }
        body.dark-theme .note-editable { background: #0f172a !important; }
        body.dark-theme select.form-control option { background: #1e293b; color: #f1f5f9; }

        /* ─── RESPONSIVE ─── */
        @media (max-width: 768px) {
            .mobile-toggle { display: flex; }
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease; position: fixed; z-index: 1000; }
            .sidebar.open { transform: translateX(0); }
            .sidebar-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: none; z-index: 999; }
            .sidebar-overlay.active { display: block; }
            .main-wrap { margin-left: 0 !important; }
            .stats-grid { grid-template-columns: 1fr; }
            table { min-width: 700px; }
            .form-control { font-size: 13px; }
            form[method="GET"] { flex-direction: column; gap: 10px; }
            .card-header { flex-direction: column; align-items: flex-start; gap: 10px; }
            .sidebar.collapsed .nav-text { display: none; }
            .sidebar.collapsed .nav-label { display: none; }
            .sidebar.collapsed .nav-item { justify-content: center; }
            .sidebar.collapsed .nav-badge { display: none; }
            .sidebar.collapsed .logo-text { display: none; }
            .sidebar { transition: width 0.3s ease; }
        }

        /* ─── SUMMERNOTE ─── */
        .note-editor.note-frame { border-color: var(--border) !important; border-radius: var(--radius-sm) !important; }
        .note-toolbar { background: #f8fafc !important; }
        .note-editing-area { background: rgba(255,255,255,0.03) !important; }
        .note-editable { color: var(--text-primary) !important; font-family: 'DM Sans', sans-serif !important; }

        /* ─── ANIMATIONS ─── */
        @keyframes fadeIn { from { opacity:0; transform: translateY(10px); } to { opacity:1; transform: translateY(0); } }
        .fade-in { animation: fadeIn 0.35s ease forwards; }
        .stagger-1 { animation-delay: 0.05s; }
        .stagger-2 { animation-delay: 0.1s; }
        .stagger-3 { animation-delay: 0.15s; }
        .stagger-4 { animation-delay: 0.2s; }
    </style>
    @stack('styles')
</head>
<body id="bodyEl">
    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-logo">
            <div class="logo-icon">⚡</div>
            <span class="logo-text">Dashboard</span>
        </div>

        <button class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="fas fa-chevron-left"></i>
        </button>

        <nav class="sidebar-nav">
            <div class="nav-label">Main</div>

            <a href="{{ route('admin.home') }}" class="nav-item {{ request()->routeIs('admin.home') ? 'active' : '' }}" data-tooltip="Home">
                <span class="nav-icon"><i class="fas fa-house"></i></span>
                <span class="nav-text">Home</span>
            </a>

            <div class="nav-label">Catalogue</div>

             <a href="{{ route('admin.banners.index') }}" class="nav-item {{ request()->routeIs('admin.banners.*') ? 'active' : '' }}" data-tooltip="Banners">
                <span class="nav-icon"><i class="fas fa-rectangle-ad"></i></span>
                <span class="nav-text">Banners</span>
            </a>
            
            <a href="{{ route('admin.categories.index') }}" class="nav-item {{ request()->routeIs('admin.categories.*') ? 'active' : '' }}" data-tooltip="Categories">
                <span class="nav-icon"><i class="fas fa-layer-group"></i></span>
                <span class="nav-text">Categories</span>
            </a>

            <a href="{{ route('admin.subcategories.index') }}" class="nav-item {{ request()->routeIs('admin.subcategories.*') ? 'active' : '' }}" data-tooltip="Subcategories">
                <span class="nav-icon"><i class="fas fa-sitemap"></i></span>
                <span class="nav-text">Subcategories</span>
            </a>

            <a href="{{ route('admin.products.index') }}" class="nav-item {{ request()->routeIs('admin.products.*') ? 'active' : '' }}" data-tooltip="Products">
                <span class="nav-icon"><i class="fas fa-box"></i></span>
                <span class="nav-text">Products</span>
            </a>

            <div class="nav-label">Media</div>

            <a href="{{ route('admin.gallery.index') }}" class="nav-item {{ request()->routeIs('admin.gallery.*') ? 'active' : '' }}" data-tooltip="Gallery">
                <span class="nav-icon"><i class="fas fa-images"></i></span>
                <span class="nav-text">Gallery</span>
            </a>

            <a href="{{ route('admin.blogs.index') }}" class="nav-item {{ request()->routeIs('admin.blogs.*') ? 'active' : '' }}" data-tooltip="Blogs">
                <span class="nav-icon"><i class="fas fa-pen-to-square"></i></span>
                <span class="nav-text">Blogs</span>
            </a>
        </nav>

        <div style="padding: 4px 12px; border-top: 1px solid var(--border);">
            <a href="#" class="nav-item" data-tooltip="Logout"
               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <span class="nav-icon"><i class="fas fa-arrow-right-from-bracket"></i></span>
                <span class="nav-text">Logout</span>
            </a>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display:none;">
                @csrf
            </form>
        </div>
    </aside>

    <div class="sidebar-overlay" onclick="closeMobileSidebar()"></div>

    <!-- MAIN -->
    <div class="main-wrap" id="mainWrap">

        <!-- TOPBAR -->
        <header class="topbar">
            <div class="topbar-left">
                <h1>@yield('page-title', 'Dashboard')</h1>
                <p>@yield('page-subtitle', 'Welcome back, Admin')</p>
            </div>
            <div class="topbar-right">

                <!-- BELL -->
                <div style="position:relative;">
                    <button class="topbar-btn" id="bellBtn" onclick="toggleBell()" aria-label="Notifications">
                        <i class="fas fa-bell" id="bellIcon"></i>
                    </button>
                    <div class="notif-dropdown" id="bellDropdown">
                        <div class="notif-dropdown-title">Notifications</div>
                        <div class="notif-empty">
                            <div class="notif-empty-icon"><i class="fas fa-bell-slash"></i></div>
                            <p>No notifications yet.<br>You're all caught up!</p>
                        </div>
                    </div>
                </div>

                <!-- GEAR -->
                <div style="position:relative;">
                    <button class="topbar-btn" id="gearBtn" onclick="toggleGear()" aria-label="Settings">
                        <i class="fas fa-moon" id="gearIcon"></i>
                    </button>
                    <div class="notif-dropdown" id="gearDropdown">
                        <div class="notif-dropdown-title">Appearance</div>
                        <button class="theme-option active" id="opt-light" onclick="setTheme('light')">
                            <span class="theme-opt-icon"><i class="fas fa-sun"></i></span>
                            <span>
                                <div class="theme-opt-label">Light</div>
                                <div class="theme-opt-sub">Bright &amp; clean</div>
                            </span>
                            <i class="fas fa-check theme-check"></i>
                        </button>
                        <button class="theme-option" id="opt-dark" onclick="setTheme('dark')">
                            <span class="theme-opt-icon"><i class="fas fa-moon"></i></span>
                            <span>
                                <div class="theme-opt-label">Dark</div>
                                <div class="theme-opt-sub">Easy on the eyes</div>
                            </span>
                            <i class="fas fa-check theme-check"></i>
                        </button>
                    </div>
                </div>

                <button class="mobile-toggle" onclick="toggleMobileSidebar()">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="avatar" title="Admin">A</div>
            </div>
        </header>

        <!-- CONTENT -->
        <main class="page-content">
            @yield('content')
        </main>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-lite.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        /* ─── SIDEBAR ─── */
        function toggleMobileSidebar() {
            document.getElementById('sidebar').classList.toggle('open');
            document.querySelector('.sidebar-overlay').classList.toggle('active');
        }

        function closeMobileSidebar() {
            document.getElementById('sidebar').classList.remove('open');
            const overlay = document.querySelector('.sidebar-overlay');
            if (overlay) overlay.classList.remove('active');
        }

        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.getElementById('bodyEl');
            sidebar.classList.toggle('collapsed');
            body.classList.toggle('sidebar-collapsed');
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        }

        if (localStorage.getItem('sidebarCollapsed') === 'true') {
            document.getElementById('sidebar').classList.add('collapsed');
            document.getElementById('bodyEl').classList.add('sidebar-collapsed');
        }

        /* ─── DELETE CONFIRM ─── */
        function confirmDelete(formId) {
            Swal.fire({
                title: 'Delete this item?',
                text: 'This action cannot be undone.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#6c63ff',
                cancelButtonColor: '#f87171',
                confirmButtonText: 'Yes, delete it!',
                background: '#ffffff',
                color: '#111827',
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(formId).submit();
                }
            });
        }

        /* ─── BELL ─── */
        let _bellOpen = false;
        let _gearOpen = false;

        function toggleBell() {
            const icon = document.getElementById('bellIcon');
            const drop = document.getElementById('bellDropdown');
            icon.classList.remove('bell-shake');
            void icon.offsetWidth;
            icon.classList.add('bell-shake');
            _bellOpen = !_bellOpen;
            drop.classList.toggle('open', _bellOpen);
            if (_gearOpen) {
                _gearOpen = false;
                document.getElementById('gearDropdown').classList.remove('open');
            }
        }

        /* ─── GEAR ─── */
        function toggleGear() {
            const icon = document.getElementById('gearIcon');
            const drop = document.getElementById('gearDropdown');
            icon.classList.remove('gear-tilt');
            void icon.offsetWidth;
            icon.classList.add('gear-tilt');
            _gearOpen = !_gearOpen;
            drop.classList.toggle('open', _gearOpen);
            if (_bellOpen) {
                _bellOpen = false;
                document.getElementById('bellDropdown').classList.remove('open');
            }
        }

        /* ─── THEME ─── */
        function setTheme(t) {
            document.body.classList.toggle('dark-theme', t === 'dark');
            document.getElementById('opt-light').classList.toggle('active', t === 'light');
            document.getElementById('opt-dark').classList.toggle('active', t === 'dark');
            localStorage.setItem('adminTheme', t);
            _gearOpen = false;
            document.getElementById('gearDropdown').classList.remove('open');
        }

        if (localStorage.getItem('adminTheme') === 'dark') {
            document.body.classList.add('dark-theme');
            document.getElementById('opt-light').classList.remove('active');
            document.getElementById('opt-dark').classList.add('active');
        }

        /* ─── CLOSE DROPDOWNS ON OUTSIDE CLICK ─── */
        document.addEventListener('click', function(e) {
            if (!e.target.closest('#bellBtn') && !e.target.closest('#bellDropdown')) {
                _bellOpen = false;
                document.getElementById('bellDropdown').classList.remove('open');
            }
            if (!e.target.closest('#gearBtn') && !e.target.closest('#gearDropdown')) {
                _gearOpen = false;
                document.getElementById('gearDropdown').classList.remove('open');
            }
        });

        /* ─── AUTO PLACEHOLDERS ─── */
        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('.form-control').forEach(function (el) {
                const label = el.closest('.form-group')?.querySelector('.form-label');
                const labelText = label ? label.textContent.trim().replace(/\s*\*$/, '') : '';

                if (el.tagName === 'INPUT' && !el.hasAttribute('placeholder')) {
                    const type = (el.getAttribute('type') || 'text').toLowerCase();
                    const map = {
                        text:     labelText ? 'Enter ' + labelText.toLowerCase() : 'Type here…',
                        search:   labelText ? 'Search ' + labelText.toLowerCase() + '…' : 'Search…',
                        email:    'e.g. admin@example.com',
                        password: 'Enter password',
                        number:   labelText ? 'Enter ' + labelText.toLowerCase() : '0',
                        url:      'https://example.com',
                        tel:      '+91 00000 00000',
                        date:     'YYYY-MM-DD',
                    };
                    if (map[type]) el.setAttribute('placeholder', map[type]);
                }

                if (el.tagName === 'TEXTAREA' && !el.hasAttribute('placeholder')) {
                    el.setAttribute('placeholder', labelText ? 'Write ' + labelText.toLowerCase() + ' here…' : 'Write here…');
                }

                if (el.tagName === 'SELECT') {
                    const first = el.querySelector('option:first-child');
                    if (first && first.value === '') {
                        if (!first.textContent.trim()) {
                            first.textContent = labelText ? 'Select ' + labelText.toLowerCase() : 'Select an option';
                        }
                        first.setAttribute('disabled', true);
                        first.setAttribute('hidden', true);
                    }
                }
            });
        });
    </script>

    @stack('scripts')

    @if(session('success'))
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: @json(session('success')),
            confirmButtonColor: '#6366f1',
            background: '#ffffff',
            color: '#111827',
            iconColor: '#22c55e',
            timer: 1700,
            showConfirmButton: false,
            timerProgressBar: true,
            showClass: { popup: 'animate__animated animate__fadeInDown' },
            hideClass: { popup: 'animate__animated animate__fadeOutUp' },
            customClass: { popup: 'swal-modern' }
        });
    </script>
    @endif

    @if(session('error'))
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: @json(session('error')),
            confirmButtonColor: '#ef4444',
            background: '#ffffff',
            color: '#111827',
            iconColor: '#ef4444',
            timer: 3000,
            showConfirmButton: false,
            timerProgressBar: true,
            showClass: { popup: 'animate__animated animate__fadeInDown' },
            hideClass: { popup: 'animate__animated animate__fadeOutUp' },
            customClass: { popup: 'swal-modern' }
        });
    </script>
    @endif
</body>
</html>
